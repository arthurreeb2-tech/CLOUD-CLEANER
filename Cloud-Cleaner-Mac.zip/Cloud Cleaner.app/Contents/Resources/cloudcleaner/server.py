"""Serveur local (127.0.0.1 uniquement) : API JSON + interface web."""
from __future__ import annotations

import json
import os
import pickle
import secrets
import shutil
import stat
import subprocess
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import analyzer, maj, scanner
from .actions import ActionError, Workspace

STATIC = os.path.join(os.path.dirname(__file__), "static")
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml"}


class App:
    def __init__(self, sources, data_dir, archive_dir, demo=False):
        self.sources = sources
        self.ws = Workspace(data_dir, archive_dir, sources)
        self.ws.guard = self._guard
        self.maj = maj.Majeur()
        self.demo = demo
        self.token = secrets.token_urlsafe(24)
        self.lock = threading.RLock()
        self.idx: scanner.Index | None = None
        self.recos: list[dict] = []
        self.summary: dict | None = None
        self.progress: dict = {"state": "idle"}
        self.job: dict | None = None        # nettoyage en cours ou dernier terminé
        self.job_cancel = threading.Event()
        self.cache_dir = os.path.join(data_dir, "cache")
        os.makedirs(self.cache_dir, exist_ok=True)
        self.hash_cache: dict = self._load("hashes.pkl") or {}
        cached = self._load("index.pkl")
        if cached and cached.get("roots") == [s.root for s in sources if s.present]:
            # Analyse précédente reprise en tâche de fond : l'app s'ouvre tout de suite.
            self.idx = cached["idx"]
            self.progress = {"state": "analyzing"}
            threading.Thread(target=self._resume_cached, daemon=True).start()

    def _resume_cached(self):
        try:
            recos, summary = self._compute(self.idx, self.progress)
            with self.lock:
                self.recos, self.summary = recos, summary
            self.progress = {"state": "ready"}
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self.progress = {"state": "error", "error": str(exc)}

    # ---------- cache ----------
    def _load(self, name):
        try:
            with open(os.path.join(self.cache_dir, name), "rb") as fh:
                return pickle.load(fh)
        except Exception:
            return None

    def _dump(self, name, obj):
        try:
            tmp = os.path.join(self.cache_dir, name + ".tmp")
            with open(tmp, "wb") as fh:
                pickle.dump(obj, fh, protocol=pickle.HIGHEST_PROTOCOL)
            os.replace(tmp, os.path.join(self.cache_dir, name))
        except OSError:
            pass

    # ---------- scan ----------
    def start_scan(self):
        with self.lock:
            if self.progress.get("state") in ("scanning", "analyzing"):
                return
            if self.job and self.job["state"] in ("running", "finalizing") \
                    and not self.job.get("rescan"):
                raise ActionError("Attends la fin de l'opération en cours avant de relancer l'analyse.")
            self.progress = {"state": "scanning", "files": 0, "dirs": 0, "bytes": 0}
        threading.Thread(target=self._scan_job, daemon=True).start()

    def _scan_job(self):
        try:
            self.sources = self._redetect()
            self.ws.sources = [s for s in self.sources if s.present]
            idx = scanner.scan(self.sources, self.progress)
            self.progress["state"] = "analyzing"
            recos, summary = self._compute(idx, self.progress)  # sans verrou : l'app reste fluide
            with self.lock:
                self.idx, self.recos, self.summary = idx, recos, summary
            self._dump("index.pkl", {"roots": [s.root for s in self.sources if s.present],
                                     "idx": idx})
            self._dump("hashes.pkl", self.hash_cache)
            self.progress = {"state": "ready"}
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self.progress = {"state": "error", "error": str(exc)}

    def _redetect(self):
        return self.sources if self.demo else scanner.detect_sources()

    def _allowed(self, path: str) -> bool:
        try:
            self.ws.locate(path)
            return True
        except ActionError:
            return False

    def _compute(self, idx, progress):
        recos, reclaim = analyzer.analyze(idx, self.sources, None, self.hash_cache, progress,
                                          allowed=self._allowed)
        # Photographie de ce qui a été proposé : revérifiée juste avant chaque déplacement.
        snap = {"files": {}, "dirs": {}, "keepers": {}}
        for r in recos:
            for g in r["groups"]:
                keeper = next((i for i in g["items"] if i.get("keep")), None)
                for i in g["items"]:
                    if keeper and not i.get("keep"):
                        snap["keepers"][i["path"]] = (keeper["path"], keeper["size"])
            for i in [x for g in r["groups"] for x in g["items"]] + r["items"]:
                d = idx.dirs.get(i["path"])
                if d is not None:
                    snap["dirs"][i["path"]] = (d.size, d.newest)
                else:
                    snap["files"][i["path"]] = (i.get("kind", "file"), i["size"], i["mtime"])
        self._snap = snap
        return recos, analyzer.summary(idx, self.sources, reclaim)

    def _guard(self, src: str) -> None:
        """Refuse de déplacer ce qui a changé depuis l'analyse (fichier modifié, dossier
        « vide » qui a reçu un fichier, exemplaire gardé d'un doublon disparu…)."""
        snap = getattr(self, "_snap", None)
        if snap is None:
            return
        changed = ActionError("modifié depuis l'analyse : relance l'analyse avant de le traiter")
        if src in snap["dirs"] or (src in snap["files"] and snap["files"][src][0] != "file"):
            size, newest = snap["dirs"].get(src) or snap["files"][src][1:]
            total, latest = 0, 0.0
            for root, _dirs, names in os.walk(src):
                for n in names:
                    try:
                        st = os.lstat(os.path.join(root, n))
                    except OSError:
                        raise changed
                    if not stat.S_ISREG(st.st_mode):  # comme l'analyse : fichiers seulement
                        continue
                    total += st.st_size
                    latest = max(latest, st.st_mtime)
            if total != size or latest > newest + 1:
                raise changed
        elif src in snap["files"]:
            _kind, size, mtime = snap["files"][src]
            st = os.lstat(src)
            if st.st_size != size or abs(st.st_mtime - mtime) > 1:
                raise changed
        keeper = snap["keepers"].get(src)
        if keeper:
            kp, ksize = keeper
            try:
                ok = os.lstat(kp).st_size == ksize
            except OSError:
                ok = False
            if not ok:
                raise ActionError("l'exemplaire gardé de ce doublon a disparu ou changé : "
                                  "relance l'analyse")

    # ---------- lecture ----------
    def display_name(self, path: str) -> str:
        for s in self.sources:
            if path == s.root:
                return s.label
        name = os.path.basename(path)
        if name == "com~apple~CloudDocs":
            return "Mes fichiers"
        if "~" in name and os.path.dirname(path) in [s.root for s in self.sources]:
            return name.split("~")[-1] + " (app)"
        return name

    def state(self):
        srcs = (self.summary or {}).get("sources") or [
            {"id": s.id, "label": s.label, "root": s.root, "present": s.present,
             "hint": s.hint, "size": 0, "files": 0, "local": 0, "cats": {}}
            for s in self.sources]
        try:
            free = shutil.disk_usage(self.ws.data_dir).free
        except OSError:
            free = None
        job = dict(self.job) if self.job else None  # copies : les tâches de fond les modifient
        return {"progress": dict(self.progress), "summary": self.summary, "sources": srcs,
                "job": job, "free_space": free, "maj": dict(self.maj.etat),
                "demo": self.demo, "cat_order": scanner.CAT_ORDER,
                "quarantine_dir": self.ws.quarantine_dir, "archive_dir": self.ws.archive_dir}

    def tree(self, path: str | None, limit: int = 14):
        idx = self.idx
        if idx is None:
            return None
        if not path:
            kids = [idx.dirs[s.root] for s in self.sources if s.present and s.root in idx.dirs]
            return {"path": "", "name": "Mes clouds", "size": sum(k.size for k in kids),
                    "files": sum(k.files for k in kids), "source": "", "depth": -1,
                    "children": [self._node(k) for k in kids], "others": None, "loose": None}
        d = idx.dirs.get(path)
        if d is None:
            return None
        kids = sorted((idx.dirs[c] for c in d.children if c in idx.dirs),
                      key=lambda k: -k.size)
        shown, rest = kids[:limit], kids[limit:]
        node = self._node(d)
        node["children"] = [self._node(k) for k in shown]
        node["others"] = ({"count": len(rest), "size": sum(k.size for k in rest),
                           "files": sum(k.files for k in rest)} if rest else None)
        loose_size = d.size - sum(k.size for k in kids)
        node["loose"] = ({"count": d.direct_files, "size": loose_size}
                         if d.direct_files else None)
        top = sorted((f for f in idx.files if os.path.dirname(f.path) == path),
                     key=lambda f: -f.size)[:8]
        node["top_files"] = [{"name": f.name, "size": f.size, "path": f.path,
                              "dataless": f.dataless} for f in top]
        return node

    def _node(self, d: scanner.DirRec):
        cat = max(d.cats, key=d.cats.get) if d.cats else "autres"
        return {"path": d.path, "name": self.display_name(d.path), "size": d.size,
                "files": d.files, "newest": d.newest, "source": d.source, "depth": d.depth,
                "has_children": bool(d.children), "cat": cat, "cats": d.cats,
                "protected": d.protected, "direct_files": d.direct_files}

    # ---------- actions (toutes en tâche de fond, une seule à la fois) ----------
    JOB_KINDS = ("quarantine", "archive", "organize", "restore", "purge")

    def start_action(self, body: dict) -> dict:
        """Valide la demande, lance la tâche de fond et rend la main tout de suite."""
        if not isinstance(body, dict):
            raise ActionError("Demande invalide.")
        kind = body.get("type")
        if kind not in self.JOB_KINDS:
            raise ActionError("Action inconnue.")
        with self.lock:
            if self.job and self.job["state"] in ("running", "finalizing"):
                raise ActionError("Une opération est déjà en cours : attends qu'elle se termine.")
            if self.progress.get("state") in ("scanning", "analyzing"):
                raise ActionError("Attends la fin de l'analyse.")
            arg, total = None, 0
            if kind in ("restore", "purge"):
                op = self.ws.load_op(str(body.get("op", "")))
                if not op or op["status"] != "done" or not op["items"]:
                    raise ActionError("Opération introuvable ou déjà traitée.")
                if kind == "purge" and op["type"] != "quarantine":
                    raise ActionError("Seule la corbeille Cloud Cleaner peut être vidée.")
                if kind == "purge" and body.get("confirm") != "SUPPRIMER":
                    raise ActionError("Confirmation manquante.")
                arg, total = op["id"], op["count"]
            elif kind == "organize":
                moves = body.get("moves")
                if not isinstance(moves, list) or not moves:
                    raise ActionError("Aucun élément sélectionné.")
                for m in moves:  # validation immédiate, avant de lancer quoi que ce soit
                    if not isinstance(m, dict):
                        raise ActionError("Demande invalide.")
                    if self.ws.locate(m.get("path"))[0].id != self.ws.locate(m.get("dest"))[0].id:
                        raise ActionError("Le rangement doit rester dans le même cloud.")
                arg, total = moves, len(moves)
            else:
                paths = body.get("paths")
                if not isinstance(paths, list) or not paths:
                    raise ActionError("Aucun élément sélectionné.")
                for p in paths:
                    self.ws.locate(p)
                arg, total = paths, len(paths)
            self.job = {"id": secrets.token_hex(4), "type": kind, "state": "running",
                        "total": total, "done": 0, "bytes": 0, "failed": 0,
                        "current": "", "started": time.time()}
            self.job_cancel = threading.Event()
            job = self.job
        threading.Thread(target=self._action_job, args=(job, kind, arg), daemon=True).start()
        return {"job": job["id"]}

    def _action_job(self, job, kind, arg):
        try:
            cancel = self.job_cancel
            if kind == "quarantine":
                op = self.ws.quarantine(arg, job, cancel)
            elif kind == "archive":
                op = self.ws.archive(arg, job, cancel)
            elif kind == "organize":
                op = self.ws.organize(arg, job, cancel)
            elif kind == "restore":
                res = self.ws.restore(arg, job, cancel)
                # Nouvelle analyse lancée AVANT d'annoncer la fin : l'interface ne peut pas
                # s'arrêter entre les deux et afficher l'ancienne analyse.
                job["rescan"] = True
                self.start_scan()
                job.update(state="done", moved=len(res["restored"]), size=job["bytes"],
                           op_id=None, cancelled=cancel.is_set(), errors=res["errors"][:20],
                           ended=time.time())
                return
            else:  # purge
                res = self.ws.purge(arg, job, cancel)
                job.update(state="done", moved=job["done"] - job["failed"], size=res["freed"],
                           op_id=None, cancelled=False, errors=res["errors"][:20],
                           ended=time.time())
                return
            job.update(state="finalizing", current="")
            # Les fichiers sont déplacés et journalisés : un échec de mise à jour de l'analyse
            # ne doit jamais masquer « Tout remettre comme avant ».
            try:
                if self.idx is not None and op["items"]:
                    with self.lock:
                        scanner.remove_paths(self.idx, [i["src"] for i in op["items"]])
                        if kind == "organize":
                            self._reindex_moved(op)
                    recos, summary = self._compute(self.idx, {})
                    with self.lock:
                        self.recos, self.summary = recos, summary
                    self._dump("index.pkl", {"roots": [s.root for s in self.sources if s.present],
                                             "idx": self.idx})
            except Exception:  # noqa: BLE001
                traceback.print_exc()
                op["errors"] = op["errors"] + [{"path": "", "error":
                                                "analyse non mise à jour : relance l'analyse"}]
            job.update(state="done", moved=len(op["items"]), size=op["size"],
                       op_id=op["id"] if op["items"] else None,
                       cancelled=bool(op.get("cancelled")), errors=op["errors"][:20],
                       ended=time.time())
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            job.update(state="error", error=str(exc), ended=time.time())

    def cancel_job(self):
        if self.job and self.job["state"] == "running" and self.job["type"] != "purge":
            self.job_cancel.set()
            self.job["cancelling"] = True
        return {"ok": True}

    def _reindex_moved(self, op):
        for it in op["items"]:
            dst, parent = it["dst"], os.path.dirname(it["dst"])
            try:
                st = os.lstat(dst)
            except OSError:
                continue
            src_parent = self.idx.dirs.get(os.path.dirname(parent))
            if parent not in self.idx.dirs and src_parent:
                self.idx.dirs[parent] = scanner.DirRec(parent, src_parent.source,
                                                       src_parent.path, src_parent.depth + 1)
                src_parent.children.append(parent)
                src_parent.direct_dirs += 1
            d = self.idx.dirs.get(parent)
            if d:
                self.idx.files.append(scanner.FileRec(
                    dst, d.source, st.st_size, st.st_mtime,
                    bool(getattr(st, "st_flags", 0) & scanner.SF_DATALESS)))
        scanner.aggregate(self.idx)

    def reveal(self, path: str):
        allowed = [s.root for s in self.sources if s.present] + [self.ws.data_dir,
                                                                 self.ws.archive_dir]
        if not isinstance(path, str) or os.path.normpath(path) != path or not any(path == a or path.startswith(a.rstrip("/") + "/") for a in allowed):
            raise ActionError("Chemin non autorisé.")
        if not os.path.lexists(path):
            raise ActionError("Ce chemin n'existe plus.")
        subprocess.run(["open", "-R", path], check=False)
        return {"ok": True}


def make_handler(app: App, port: int):
    hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *args):  # silencieux
            pass

        def _send(self, code, body, ctype="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(
                body, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)

        def _guard(self) -> bool:
            if self.headers.get("Host") not in hosts:  # anti DNS-rebinding
                self._send(403, {"error": "Hôte refusé."})
                return False
            return True

        def do_GET(self):
            if not self._guard():
                return
            url = urlparse(self.path)
            q = parse_qs(url.query)
            try:
                if url.path == "/":
                    with open(os.path.join(STATIC, "index.html"), encoding="utf-8") as fh:
                        html = fh.read().replace("__TOKEN__", app.token)
                    return self._send(200, html.encode(), MIME[".html"])
                if url.path.startswith("/static/"):
                    name = os.path.basename(url.path)
                    fp = os.path.join(STATIC, name)
                    ext = os.path.splitext(name)[1]
                    if ext in MIME and os.path.isfile(fp):
                        with open(fp, "rb") as fh:
                            return self._send(200, fh.read(), MIME[ext])
                    return self._send(404, {"error": "introuvable"})
                if self.headers.get("X-Token") != app.token:
                    return self._send(403, {"error": "Jeton manquant."})
                if url.path == "/api/state":
                    return self._send(200, app.state())
                if url.path == "/api/tree":
                    node = app.tree(q.get("path", [""])[0])
                    return self._send(200 if node else 404, node or {"error": "introuvable"})
                if url.path == "/api/recos":
                    return self._send(200, app.recos)
                if url.path == "/api/journal":
                    return self._send(200, [
                        {**o, "items": o["items"][:3], "errors": o["errors"][:3]}
                        for o in reversed(app.ws.journal())])
                self._send(404, {"error": "introuvable"})
            except Exception as exc:  # noqa: BLE001
                traceback.print_exc()
                self._send(500, {"error": str(exc)})

        def do_POST(self):
            if not self._guard():
                return
            if self.headers.get("X-Token") != app.token:
                return self._send(403, {"error": "Jeton manquant."})
            try:
                n = int(self.headers.get("Content-Length") or 0)
                try:
                    body = json.loads(self.rfile.read(n) or b"{}")
                except ValueError:
                    raise ActionError("Demande invalide.")
                if not isinstance(body, dict):
                    raise ActionError("Demande invalide.")
                path = urlparse(self.path).path
                if path == "/api/scan":
                    app.start_scan()
                    return self._send(200, {"ok": True})
                if path == "/api/action":
                    return self._send(200, app.start_action(body))
                if path == "/api/job/cancel":
                    return self._send(200, app.cancel_job())
                if path == "/api/restore":
                    return self._send(200, app.start_action({**body, "type": "restore"}))
                if path == "/api/purge":
                    return self._send(200, app.start_action({**body, "type": "purge"}))
                if path == "/api/reveal":
                    return self._send(200, app.reveal(body.get("path", "")))
                self._send(404, {"error": "introuvable"})
            except ActionError as exc:
                self._send(400, {"error": str(exc)})
            except Exception as exc:  # noqa: BLE001
                traceback.print_exc()
                self._send(500, {"error": str(exc)})

    return Handler


def serve(app: App, port: int):
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(app, port))
    print(f"Cloud Cleaner : http://127.0.0.1:{port}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
