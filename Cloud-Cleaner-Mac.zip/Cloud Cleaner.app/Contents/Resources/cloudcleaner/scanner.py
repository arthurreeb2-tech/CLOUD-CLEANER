"""Détection des dossiers cloud synchronisés et scan des métadonnées.

Le scan ne lit jamais le contenu des fichiers : il n'utilise que lstat(), ce qui
évite de déclencher le téléchargement des fichiers « en ligne uniquement ».
"""
from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass, field

SF_DATALESS = 0x40000000  # fichier présent dans le cloud mais non téléchargé

# Dossiers traités comme un seul élément (paquets macOS).
BUNDLE_EXTS = {
    ".app", ".photoslibrary", ".band", ".logicx", ".key", ".pages", ".numbers",
    ".rtfd", ".imovielibrary", ".fcpbundle", ".tvlibrary", ".musiclibrary",
    ".xcodeproj", ".xcworkspace", ".playground", ".bundle", ".framework",
    ".pkg", ".mpkg", ".scriv", ".sparsebundle", ".theater", ".photolibrary",
    ".aplibrary", ".download", ".lproj", ".xcassets", ".dSYM",
}
# Dossiers régénérables : agrégés en un seul élément, proposés au nettoyage.
REGEN_DIRS = {
    "node_modules", ".venv", "venv", "__pycache__", ".gradle", "Pods",
    "DerivedData", ".next", ".nuxt", ".tox", ".pytest_cache", ".mypy_cache",
    "bower_components", ".cache", ".parcel-cache", ".turbo",
}

# Dossiers système des fournisseurs cloud : jamais parcourus.
SKIP_DIRS = {".Trash", ".Trashes", ".TemporaryItems", ".DocumentRevisions-V100",
             ".fseventsd", ".Spotlight-V100", ".tmp.driveupload", ".tmp.drivedownload"}

CATEGORIES = {
    "images": {".jpg", ".jpeg", ".png", ".gif", ".heic", ".heif", ".tif", ".tiff", ".bmp",
               ".webp", ".raw", ".cr2", ".cr3", ".nef", ".arw", ".dng", ".svg", ".psd",
               ".ai", ".eps", ".ico", ".avif", ".photoslibrary", ".sketch", ".fig", ".xcf"},
    "videos": {".mp4", ".mov", ".avi", ".mkv", ".m4v", ".wmv", ".flv", ".webm", ".mts",
               ".m2ts", ".3gp", ".mpg", ".mpeg", ".imovielibrary", ".fcpbundle", ".prproj"},
    "audio": {".mp3", ".wav", ".aac", ".flac", ".m4a", ".ogg", ".aiff", ".aif", ".wma",
              ".band", ".logicx", ".mid", ".midi", ".caf", ".opus"},
    "documents": {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf",
                  ".rtfd", ".odt", ".ods", ".odp", ".pages", ".numbers", ".key", ".md",
                  ".csv", ".epub", ".msg", ".eml", ".one", ".vsdx", ".pub"},
    "archives": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz", ".zst",
                 ".sparsebundle", ".bak", ".backup"},
    "code": {".py", ".js", ".ts", ".tsx", ".jsx", ".html", ".css", ".json", ".xml", ".yml",
             ".yaml", ".swift", ".rs", ".go", ".java", ".c", ".cpp", ".h", ".sh", ".sql",
             ".php", ".rb", ".ipynb", ".lock", ".toml", ".map", ".wasm", ".xcodeproj"},
    "installateurs": {".dmg", ".pkg", ".mpkg", ".exe", ".msi", ".iso", ".app", ".apk",
                      ".ipa", ".deb", ".rpm"},
    "3d_cao": {".dwg", ".dxf", ".skp", ".3dm", ".stl", ".obj", ".fbx", ".blend", ".step",
               ".stp", ".ifc", ".rvt", ".3d", ".2d", ".f3d", ".iges", ".igs", ".glb", ".gltf"},
}
EXT_TO_CAT = {ext: cat for cat, exts in CATEGORIES.items() for ext in exts}
CAT_ORDER = ["images", "videos", "audio", "documents", "archives", "code",
             "installateurs", "3d_cao", "autres"]


def category_of(name: str) -> str:
    return EXT_TO_CAT.get(os.path.splitext(name)[1].lower(), "autres")


@dataclass
class Source:
    id: str          # icloud | gdrive | onedrive | demo-…
    label: str
    root: str
    present: bool = True
    hint: str = ""


@dataclass
class FileRec:
    path: str        # chemin absolu
    source: str
    size: int
    mtime: float
    dataless: bool = False
    kind: str = "file"   # file | bundle | regen
    protected: bool = False  # données d'app iCloud : jamais proposées au nettoyage

    @property
    def name(self) -> str:
        return os.path.basename(self.path)


@dataclass
class DirRec:
    path: str
    source: str
    parent: str | None
    depth: int
    size: int = 0            # taille totale récursive
    files: int = 0           # nombre de fichiers récursif
    direct_files: int = 0
    direct_dirs: int = 0
    newest: float = 0.0
    protected: bool = False
    unlisted: bool = False   # contenu pas entièrement connu (délai, erreur, lien…)
    online: int = 0          # octets pas encore téléchargés sur ce Mac (récursif)
    children: list[str] = field(default_factory=list)
    cats: dict[str, int] = field(default_factory=dict)


@dataclass
class Index:
    files: list[FileRec] = field(default_factory=list)
    dirs: dict[str, DirRec] = field(default_factory=dict)
    scanned_at: float = 0.0
    errors: int = 0
    unlisted: dict[str, int] = field(default_factory=dict)  # dossiers en ligne non lus, par source


def detect_sources(home: str | None = None) -> list[Source]:
    home = home or os.path.expanduser("~")
    out: list[Source] = []
    icloud = os.path.join(home, "Library", "Mobile Documents")
    out.append(Source("icloud", "iCloud Drive", icloud, os.path.isdir(icloud),
                      "Active iCloud Drive dans Réglages Système › Identifiant Apple › iCloud."))
    cs = os.path.join(home, "Library", "CloudStorage")
    try:
        entries = sorted(os.listdir(cs)) if os.path.isdir(cs) else []
    except OSError:  # accès refusé par macOS : aucun cloud tiers détecté plutôt qu'un plantage
        entries = []
    for prefix, sid, label, hint in (
        ("GoogleDrive", "gdrive", "Google Drive",
         "Installe « Google Drive pour ordinateur » puis connecte ton compte."),
        ("OneDrive", "onedrive", "OneDrive",
         "Installe l'app OneDrive puis connecte ton compte."),
    ):
        # Bibliothèques SharePoint partagées (« OneDrive-SharedLibraries-… ») : communes à
        # d'autres personnes, jamais analysées ni modifiées.
        found = [e for e in entries if e.startswith(prefix) and "SharedLibraries" not in e]
        if not found:
            out.append(Source(sid, label, os.path.join(cs, prefix), False, hint))
        for i, e in enumerate(found):
            suffix = e[len(prefix):].lstrip("-")
            out.append(Source(sid if i == 0 else f"{sid}{i + 1}",
                              f"{label} ({suffix})" if suffix and len(found) > 1 else label,
                              os.path.join(cs, e)))
    return out


LIST_TIMEOUT = 25      # secondes accordées au fournisseur cloud pour lister un dossier
MAX_TIMEOUTS = 6       # au-delà, les dossiers « en ligne » restants de la source sont ignorés


def _listdir(path: str, timeout: float | None = None):
    """Liste un dossier sans jamais bloquer : None si le fournisseur cloud ne répond pas."""
    box: dict = {}

    def work():
        try:
            with os.scandir(path) as it:
                box["entries"] = list(it)
        except OSError as exc:
            box["error"] = exc

    th = threading.Thread(target=work, daemon=True)
    th.start()
    th.join(LIST_TIMEOUT if timeout is None else timeout)
    if th.is_alive():
        return None
    if "error" in box:
        raise box["error"]
    return box["entries"]


PARALLEL = 12  # dossiers listés en parallèle (le listage « en ligne » attend le réseau)


def _list_many(paths: list[str], timeout: float | None = None) -> list:
    """Liste plusieurs dossiers en parallèle. Par dossier : entrées, None (délai) ou OSError."""
    boxes = []
    for path in paths:
        box: dict = {}

        def work(path=path, box=box):
            try:
                with os.scandir(path) as it:
                    box["entries"] = list(it)
            except OSError as exc:
                box["error"] = exc

        th = threading.Thread(target=work, daemon=True)
        th.start()
        boxes.append((th, box))
    deadline = time.time() + (LIST_TIMEOUT if timeout is None else timeout)
    out = []
    for th, box in boxes:
        th.join(max(0.0, deadline - time.time()))
        out.append(None if th.is_alive() else box.get("error") or box.get("entries", []))
    return out


def _is_dataless(st) -> bool:
    return bool(getattr(st, "st_flags", 0) & SF_DATALESS)


def _tree_size(path: str) -> tuple[int, float, bool, int]:
    """Taille, mtime le plus récent, présence d'éléments non téléchargés, erreurs.

    Les sous-dossiers « en ligne uniquement » ne sont pas parcourus."""
    total, newest, dataless, errors = 0, 0.0, False, 0
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            entries = _listdir(cur)
        except OSError:
            errors += 1
            continue
        if entries is None:
            errors += 1
            continue
        for e in entries:
            try:
                st = e.stat(follow_symlinks=False)
                if e.is_dir(follow_symlinks=False):
                    if _is_dataless(st):
                        dataless = True
                    else:
                        stack.append(e.path)
                elif e.is_file(follow_symlinks=False):
                    total += st.st_size
                    newest = max(newest, st.st_mtime)
                    if _is_dataless(st):
                        dataless = True
            except OSError:
                errors += 1
    return total, newest, dataless, errors


def scan(sources: list[Source], progress: dict | None = None) -> Index:
    idx = Index()
    progress = progress if progress is not None else {}
    progress.update(files=0, dirs=0, bytes=0, current="")
    for src in sources:
        if not src.present:
            continue
        root = src.root
        idx.dirs[root] = DirRec(root, src.id, None, 0)
        stack = [(root, False)]
        timeouts = 0
        pending: list = []
        while stack or pending:
            if not pending:
                batch = []
                while stack and len(batch) < PARALLEL:
                    cur, cur_dataless = stack.pop()
                    if cur_dataless and timeouts >= MAX_TIMEOUTS:
                        idx.unlisted[src.id] = idx.unlisted.get(src.id, 0) + 1
                        idx.dirs[cur].unlisted = True
                    else:
                        batch.append(cur)
                progress["current"] = batch[0] if batch else ""
                pending = list(zip(batch, _list_many(batch)))
                continue
            cur, entries = pending.pop()
            drec = idx.dirs[cur]
            if isinstance(entries, OSError):
                idx.errors += 1
                drec.unlisted = True  # contenu inconnu : jamais « vide » ni « ancien »
                continue
            if entries is None:  # le fournisseur cloud ne répond pas pour ce dossier
                timeouts += 1
                idx.unlisted[src.id] = idx.unlisted.get(src.id, 0) + 1
                drec.unlisted = True
                continue
            for e in entries:
                name = e.name
                if name in SKIP_DIRS:
                    drec.unlisted = True  # contenu ignoré : le dossier n'est jamais « vide »
                    continue
                try:
                    st = e.stat(follow_symlinks=False)
                    is_dir = e.is_dir(follow_symlinks=False)
                    is_file = e.is_file(follow_symlinks=False)
                except OSError:
                    idx.errors += 1
                    drec.unlisted = True
                    continue
                if not (is_dir or is_file):
                    drec.unlisted = True  # liens symboliques, sockets… : contenu incertain
                    continue
                # Dans iCloud, tout ce qui n'est pas « com~apple~CloudDocs » appartient à une app.
                protected = drec.protected or (
                    src.id == "icloud" and drec.depth == 0 and name != "com~apple~CloudDocs")
                if is_dir:
                    ext = os.path.splitext(name)[1].lower()
                    if ext in BUNDLE_EXTS or name in REGEN_DIRS:
                        if _is_dataless(st):
                            # Paquet resté dans le cloud : taille inconnue sans tout télécharger.
                            size, newest, dl, errs = 0, st.st_mtime, True, 0
                            drec.unlisted = True  # le dossier parent n'est pas « connu »
                        else:
                            size, newest, dl, errs = _tree_size(e.path)
                        idx.errors += errs
                        idx.files.append(FileRec(
                            e.path, src.id, size, newest or st.st_mtime, dl,
                            "regen" if name in REGEN_DIRS else "bundle", protected))
                        progress["files"] += 1
                        progress["bytes"] += size
                    else:
                        idx.dirs[e.path] = DirRec(e.path, src.id, cur, drec.depth + 1,
                                                  protected=protected)
                        drec.children.append(e.path)
                        drec.direct_dirs += 1
                        stack.append((e.path, _is_dataless(st)))
                        progress["dirs"] += 1
                else:
                    dataless = _is_dataless(st)
                    # Ancien format de substitut iCloud : « .nom.icloud »
                    if name.startswith(".") and name.endswith(".icloud"):
                        dataless = True
                    idx.files.append(FileRec(e.path, src.id, st.st_size, st.st_mtime,
                                             dataless, "file", protected))
                    progress["files"] += 1
                    progress["bytes"] += st.st_size
    aggregate(idx)
    idx.scanned_at = time.time()
    return idx


def aggregate(idx: Index) -> None:
    """Recalcule les totaux récursifs des dossiers à partir de la liste des fichiers."""
    for d in idx.dirs.values():
        d.size = d.files = d.direct_files = d.online = 0
        d.newest = 0.0
        d.cats = {}
    for f in idx.files:
        parent = os.path.dirname(f.path)
        d = idx.dirs.get(parent)
        if d is None:
            continue
        d.direct_files += 1
        cat = category_of(f.name)
        while d is not None:
            d.size += f.size
            d.files += 1
            if f.mtime > d.newest:
                d.newest = f.mtime
            d.cats[cat] = d.cats.get(cat, 0) + f.size
            if f.dataless:
                d.online += f.size
            d = idx.dirs.get(d.parent) if d.parent else None


def remove_paths(idx: Index, paths: list[str]) -> None:
    """Retire de l'index des fichiers ou dossiers déplacés, puis recalcule les totaux."""
    exact = set(paths)
    prefixes = tuple(p.rstrip("/") + "/" for p in paths)
    idx.files = [f for f in idx.files
                 if f.path not in exact and not f.path.startswith(prefixes)]
    for p in list(idx.dirs):
        if p in exact or p.startswith(prefixes):
            d = idx.dirs.pop(p)
            par = idx.dirs.get(d.parent) if d.parent else None
            if par and p in par.children:
                par.children.remove(p)
                par.direct_dirs = len(par.children)
    aggregate(idx)
