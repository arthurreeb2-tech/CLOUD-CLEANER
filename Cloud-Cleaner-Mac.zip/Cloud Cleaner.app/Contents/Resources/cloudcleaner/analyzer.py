"""Moteur de recommandations : doublons, résidus, archivage, structure."""
from __future__ import annotations

import hashlib
import os
import re
import time
from collections import defaultdict

from .actions import is_google_native
from .scanner import FileRec, Index, Source, category_of

MB = 1024 * 1024
YEAR = 365.25 * 86400

DEFAULTS = {
    "old_years": 2,          # un dossier non modifié depuis N années est archivable
    "big_mb": 200,           # seuil « gros fichier »
    "dup_min_kb": 50,        # taille minimale pour chercher des doublons
    "screenshot_months": 6,
    "crowded": 200,          # fichiers en vrac dans un même dossier
    "deep": 8,               # profondeur d'arborescence excessive
}

JUNK_NAMES = {".ds_store", "thumbs.db", "desktop.ini", ".localized", "ehthumbs.db",
              ".spotlight-v100", ".fseventsd", ".temporaryitems", ".apdisk"}
JUNK_EXTS = {".tmp", ".temp", ".crdownload", ".part", ".partial", ".download", ".bak~",
             ".swp"}
INSTALLER_EXTS = {".dmg", ".pkg", ".mpkg", ".exe", ".msi", ".iso", ".apk", ".ipa", ".deb"}
COPY_RE = re.compile(r"( copie( \d+)?| - copie| copy( \d+)?|^copie de |^copy of | ?\(\d+\)| \d$)",
                     re.I)
GENERIC_DIR_RE = re.compile(
    r"^(nouveau dossier|untitled folder|new folder|dossier sans titre|sans titre|"
    r"divers|misc|tmp|temp|test|a trier|à trier|trucs|stuff|autre|autres)( ?\(?\d+\)?)?$", re.I)
SCREENSHOT_RE = re.compile(r"^(capture d.écran|screenshot|screen shot|capture d’écran|"
                           r"enregistrement de l.écran|screen recording)", re.I)

LIST_CAP = 2000   # éléments transmis par recommandation (au-delà : relancer après nettoyage)
GROUP_CAP = 1000

ORGANIZE_DIRS = {
    # « Docs » et non « Documents » : ce nom est réservé au dossier Documents synchronisé
    # par macOS dans iCloud Drive.
    "images": "Images", "videos": "Vidéos", "audio": "Audio", "documents": "Docs",
    "archives": "Archives", "code": "Code", "installateurs": "Installateurs",
    "3d_cao": "3D et CAO", "autres": "Autres fichiers",
}


SAMPLE_LIMIT = 8 * MB


def _hash_file(path: str, size: int, full: bool) -> str:
    """Empreinte du contenu. full=False : échantillon (début, milieu, fin) pour un tri rapide ;
    deux fichiers ne sont déclarés identiques qu'après comparaison du contenu complet."""
    h = hashlib.blake2b(digest_size=16)
    h.update(str(size).encode())
    with open(path, "rb") as fh:
        if full or size <= SAMPLE_LIMIT:
            while True:
                chunk = fh.read(MB)
                if not chunk:
                    break
                h.update(chunk)
        else:
            for off in (0, size // 2 - MB // 2, size - MB):
                fh.seek(off)
                h.update(fh.read(MB))
    return h.hexdigest()


def _digest(f: FileRec, full: bool, cache: dict) -> str:
    full = full or f.size <= SAMPLE_LIMIT
    ck = (f.path, f.size, int(f.mtime), "full" if full else "sample")
    digest = cache.get(ck)
    if digest is None:
        try:
            digest = _hash_file(f.path, f.size, full)
        except OSError:
            digest = ""
        cache[ck] = digest
    return digest


VCS_PARTS = ("/.git/", "/.svn/", "/.hg/")


def _item(f: FileRec, **extra) -> dict:
    d = {"path": f.path, "name": f.name, "size": f.size, "mtime": f.mtime,
         "dataless": f.dataless, "online": f.size if f.dataless else 0,
         "source": f.source, "kind": f.kind}
    d.update(extra)
    return d


def _keeper_rank(f: FileRec):
    stem = os.path.splitext(f.name)[0]
    return (bool(COPY_RE.search(stem)), f.path.count("/"), f.mtime, len(f.path))


def find_duplicates(files: list[FileRec], cfg: dict, hash_cache: dict,
                    progress: dict | None = None) -> list[dict]:
    min_size = cfg["dup_min_kb"] * 1024
    by_size: dict[int, list[FileRec]] = defaultdict(list)
    for f in files:
        if f.kind == "file" and not f.protected and f.size >= min_size \
                and not any(v in f.path for v in VCS_PARTS):
            by_size[f.size].append(f)
    buckets = [g for g in by_size.values() if len(g) > 1]
    todo = sum(1 for g in buckets for f in g if not f.dataless)
    done = 0
    groups = []
    for bucket in buckets:
        keyed: dict[tuple, list[FileRec]] = defaultdict(list)
        for f in bucket:
            if f.dataless:
                keyed[("n", f.name.lower())].append(f)
                continue
            digest = _digest(f, False, hash_cache)
            done += 1
            if progress is not None:
                progress.update(phase="doublons", done=done, total=todo)
            if digest:
                keyed[("h", digest)].append(f)
        # Gros fichiers : l'échantillon ne suffit pas, on compare le contenu complet.
        for key in [k for k in keyed if k[0] == "h" and len(keyed[k]) > 1
                    and keyed[k][0].size > SAMPLE_LIMIT]:
            members = keyed.pop(key)
            for f in members:
                full = _digest(f, True, hash_cache)
                if full:
                    keyed[("h", "full:" + full)].append(f)
        # Rattache les fichiers non téléchargés au groupe local de même nom.
        probable: set[tuple] = set()
        for key in [k for k in keyed if k[0] == "n"]:
            for hk in [k for k in keyed if k[0] == "h"]:
                if any(x.name.lower() == key[1] for x in keyed[hk]):
                    keyed[hk].extend(keyed.pop(key))
                    probable.add(hk)
                    break
        for key, members in keyed.items():
            if len(members) < 2:
                continue
            members.sort(key=_keeper_rank)
            certain = key[0] == "h" and key not in probable
            groups.append({
                "certain": certain,
                "size": members[0].size,
                "gain": members[0].size * (len(members) - 1),
                "cross": len({m.source for m in members}) > 1,
                "items": [_item(m, keep=(i == 0)) for i, m in enumerate(members)],
            })
    groups.sort(key=lambda g: -g["gain"])
    return groups


def analyze(idx: Index, sources: list[Source], cfg: dict | None = None,
            hash_cache: dict | None = None, progress: dict | None = None,
            allowed=None) -> list[dict]:
    """allowed(chemin) -> bool : même règle que le serveur pour ce qui est modifiable."""
    cfg = {**DEFAULTS, **(cfg or {})}
    hash_cache = hash_cache if hash_cache is not None else {}
    now = time.time()
    # Fichiers d'apps iCloud et anciens substituts « .nom.icloud » : jamais proposés.
    # Paquets et dossiers techniques restés dans le cloud : taille inconnue, jamais proposés.
    # Documents Google natifs (.gdoc…) : simples raccourcis vers un document en ligne.
    files = [f for f in idx.files if not f.protected
             and not (f.name.startswith(".") and f.name.endswith(".icloud"))
             and not (f.kind != "file" and f.dataless)
             and not is_google_native(f.name)]
    roots = {s.id: s.root for s in sources if s.present}
    # Racine « utilisateur » de chaque source (iCloud Drive vit dans com~apple~CloudDocs).
    user_roots = {sid: (os.path.join(r, "com~apple~CloudDocs")
                        if os.path.isdir(os.path.join(r, "com~apple~CloudDocs")) else r)
                  for sid, r in roots.items()}
    recos: list[dict] = []
    reclaimable: dict[str, int] = {}

    def ok(path: str) -> bool:
        return allowed is None or allowed(path)

    def add(rid, title, why, action, items, groups=None, safe=False, level="normal"):
        """safe=True : sans risque, présélectionné et proposé au « Nettoyer » de l'accueil.
        Seuls les éléments que le serveur acceptera de déplacer sont proposés."""
        if action != "info":
            items = [i for i in items if ok(i["path"]) and ("dest" not in i or ok(i["dest"]))]
            kept = []
            for g in groups or []:
                members = [dict(i, keep=False) for i in g["items"] if ok(i["path"])]
                if len(members) < 2:
                    continue
                members[0]["keep"] = True  # déjà triés : le mieux rangé est gardé
                kept.append(dict(g, items=members, gain=g["size"] * (len(members) - 1)))
            groups = kept
        if not items and not groups:
            return
        gain = (sum(g["gain"] for g in groups) if groups
                else sum(i.get("size", 0) for i in items))
        count = len(groups) if groups else len(items)
        items, groups = items[:LIST_CAP], (groups or [])[:GROUP_CAP]
        if safe:
            for it in ([i for g in groups if g["certain"] for i in g["items"] if not i["keep"]]
                       if groups else items):
                reclaimable[it["path"]] = it.get("size", 0)
        recos.append({"id": rid, "title": title, "why": why, "action": action,
                      "items": items, "groups": groups, "count": count,
                      "gain": gain, "safe": safe, "checked": safe, "level": level})

    # 1. Catégories par type (un fichier n'appartient qu'à une seule proposition)
    junk, installers, regen, shots = [], [], [], []
    for f in files:
        low = f.name.lower()
        ext = os.path.splitext(low)[1]
        if f.kind == "regen":
            if _regen_verified(f.path):  # sinon : jamais proposé (peut contenir autre chose)
                regen.append(_item(f))
        elif f.kind == "file" and (low in JUNK_NAMES or ext in JUNK_EXTS
                                   or low.startswith("~$") or low.startswith("._")):
            junk.append(_item(f))
        elif ext in INSTALLER_EXTS:
            installers.append(_item(f))
        elif SCREENSHOT_RE.match(f.name) and now - f.mtime > cfg["screenshot_months"] * YEAR / 12:
            shots.append(_item(f))
    for lst in (junk, installers, regen, shots):
        lst.sort(key=lambda i: -i["size"])

    # 2. Doublons : hors fichiers déjà classés ci-dessus, sinon « Nettoyer » pourrait retirer
    # aussi l'exemplaire gardé (ex. deux .dmg identiques, aussi listés comme installateurs).
    classified = {i["path"] for lst in (junk, installers, regen, shots) for i in lst}
    groups = [g for g in find_duplicates(files, cfg, hash_cache, progress)
              if not any(i["path"] in classified for i in g["items"])]
    add("doublons", "Doublons",
        "Le même fichier présent plusieurs fois. Un exemplaire est toujours gardé (le mieux "
        "rangé) ; seules les copies sont retirées. Les doublons « à vérifier » ont le même nom "
        "et la même taille mais leur contenu n'a pas pu être comparé : ils ne sont pas cochés.",
        "quarantine", [], groups, safe=True)
    add("residus", "Fichiers inutiles",
        "Fichiers techniques créés automatiquement (.DS_Store, fichiers temporaires, "
        "téléchargements interrompus). Ils ne servent à rien.",
        "quarantine", junk, safe=True)
    add("installateurs", "Programmes d'installation",
        "Fichiers .dmg, .pkg, .exe… qui servent à installer un logiciel. Ils se "
        "re-téléchargent à tout moment sur le site de l'éditeur.",
        "quarantine", installers, safe=True)
    add("regen", "Dossiers techniques recréables",
        "Dossiers créés par des outils de programmation (node_modules, .venv…). Ils se "
        "recréent automatiquement et n'ont rien à faire dans un cloud.",
        "quarantine", regen, safe=True)
    add("captures", "Anciennes captures d'écran",
        f"Captures et enregistrements d'écran de plus de {cfg['screenshot_months']} mois. "
        "À regarder avant de retirer.", "quarantine", shots)

    # Dossiers dont le contenu n'est pas entièrement connu (et leurs parents) :
    # jamais proposés comme « vides » ni « anciens ».
    uncertain: set[str] = set()
    google_dirs = {os.path.dirname(f.path) for f in idx.files if is_google_native(f.name)}
    for d in idx.dirs.values():
        if getattr(d, "unlisted", False) or d.path in google_dirs:
            cur = d
            while cur is not None and cur.path not in uncertain:
                uncertain.add(cur.path)
                cur = idx.dirs.get(cur.parent) if cur.parent else None
    # Racines et dossiers principaux (Mon Drive, Drives partagés…) : jamais déplacés en bloc.
    skip = set(roots.values()) | set(user_roots.values())
    for sid, r in roots.items():
        if sid.startswith("gdrive") and r in idx.dirs:
            skip.update(idx.dirs[r].children)
    if "icloud" in user_roots:  # « Bureau et Documents » synchronisés par macOS
        skip.update(os.path.join(user_roots["icloud"], n) for n in ("Desktop", "Documents"))

    # 3. Dossiers dormants → archivage
    cutoff = now - cfg["old_years"] * YEAR
    dormant, dormant_set = [], set()
    for d in sorted(idx.dirs.values(), key=lambda d: d.depth):
        if d.protected or d.path in skip or d.path in uncertain or d.files == 0 \
                or d.size < 20 * MB:
            continue
        if d.newest < cutoff and not _has_ancestor(d.path, dormant_set):
            dormant_set.add(d.path)
            dormant.append({"path": d.path, "name": os.path.basename(d.path), "size": d.size,
                            "mtime": d.newest, "source": d.source, "kind": "dir",
                            "online": getattr(d, "online", 0), "note": _nfiles(d.files)})
    dormant.sort(key=lambda i: -i["size"])
    add("dormants", f"Dossiers non touchés depuis {cfg['old_years']} ans",
        f"Aucun fichier de ces dossiers n'a été modifié depuis plus de {cfg['old_years']} ans. "
        "Les déplacer sur ce Mac libère le cloud, mais ils ne seront plus visibles sur "
        "tes autres appareils (iPhone, autre Mac…).", "archive", dormant)

    dormant_prefixes = tuple(x["path"] + "/" for x in dormant)
    listed = {i["path"] for i in installers + junk}
    big = [_item(f) for f in files
           if f.size >= cfg["big_mb"] * MB and f.kind != "regen" and f.path not in listed
           and not f.path.startswith(dormant_prefixes)]
    big.sort(key=lambda i: -i["size"])
    add("gros", "Très gros fichiers",
        f"Fichiers de plus de {cfg['big_mb']} Mo. Coche ceux dont tu n'as plus besoin sur tes "
        "autres appareils : ils seront déplacés sur ce Mac.", "archive", big)

    # 4. Dossiers vides (jamais un dossier dont le contenu n'a pas pu être lu)
    empty, empty_set = [], set()
    for d in sorted(idx.dirs.values(), key=lambda d: d.depth):
        if d.protected or d.path in skip or d.files > 0 or d.path in uncertain:
            continue
        if not _has_ancestor(d.path, empty_set):
            empty_set.add(d.path)
            empty.append({"path": d.path, "name": os.path.basename(d.path), "size": 0,
                          "mtime": 0, "source": d.source, "kind": "dir", "online": 0})
    add("vides", "Dossiers vides", "Dossiers qui ne contiennent aucun fichier.",
        "quarantine", empty, safe=True)

    # 5. Rangement du vrac à la racine
    loose = []
    for sid, uroot in user_roots.items():
        root_files = [f for f in files if os.path.dirname(f.path) == uroot
                      and f.kind == "file" and not f.name.startswith(".")]
        if len(root_files) < 8:
            continue
        for f in root_files:
            dest_dir = ORGANIZE_DIRS[category_of(f.name)]
            loose.append(_item(f, dest=os.path.join(uroot, dest_dir, f.name),
                               note=f"→ {dest_dir}/"))
    add("vrac", "Fichiers en vrac à la racine",
        "Beaucoup de fichiers posés directement à la racine. Proposition : les ranger dans un "
        "dossier par type (Docs, Images, Vidéos…). Ils restent dans le cloud.",
        "organize", loose, level="structure")

    # 6. Constats de structure (informatifs)
    crowded, deep, generic, copies = [], [], [], []
    for d in idx.dirs.values():
        if d.protected or d.path in skip:
            continue
        base = {"path": d.path, "name": os.path.basename(d.path), "size": d.size,
                "mtime": d.newest, "source": d.source, "kind": "dir"}
        if d.direct_files >= cfg["crowded"]:
            crowded.append({**base, "note": f"{d.direct_files} fichiers en vrac"})
        rel_depth = d.path.count("/") - user_roots[d.source].count("/")
        if rel_depth == cfg["deep"]:  # premier niveau trop profond : un signalement par branche
            deep.append({**base, "note": f"{rel_depth} niveaux ou plus"})
        if GENERIC_DIR_RE.match(base["name"]) and d.files > 0:
            generic.append({**base, "note": _nfiles(d.files)})
    for f in files:
        if f.kind == "file" and COPY_RE.search(os.path.splitext(f.name)[0]) \
                and re.search(r"(copie|copy|\(\d+\))", f.name, re.I):
            copies.append(_item(f))
    crowded.sort(key=lambda i: -int(i["note"].split()[0]))
    deep.sort(key=lambda i: -int(i["note"].split()[0]))
    copies.sort(key=lambda i: -i["size"])
    add("surcharges", "Dossiers trop chargés",
        f"Plus de {cfg['crowded']} fichiers posés au même niveau : difficile de s'y retrouver. "
        "Amélioration : créer des sous-dossiers par année ou par projet.",
        "info", crowded, level="structure")
    add("profonds", "Arborescence trop profonde",
        f"Dossiers enfouis à {cfg['deep']} niveaux ou plus. Amélioration : aplatir en "
        "remontant le contenu de quelques niveaux.", "info", deep, level="structure")
    add("generiques", "Dossiers au nom générique",
        "« Nouveau dossier », « divers », « à trier »… Amélioration : leur donner un nom "
        "parlant ou répartir leur contenu.", "info", generic, level="structure")
    add("copies", "Fichiers nommés « copie »",
        "Noms laissant penser à une copie (« copie », « (1) »…), sans que le contenu soit "
        "identique à un autre fichier. À vérifier à la main.", "info", copies, level="structure")
    # Gain total sans double compte (un fichier déjà couvert par un dossier coché ne compte pas).
    keys = set(reclaimable)
    reclaim = sum(size for path, size in reclaimable.items() if not _has_ancestor(path, keys))
    return recos, reclaim


# Un dossier technique n'est « recréable » que s'il est à côté du fichier qui sert à le
# recréer. Sans ce fichier (un « venv » ou « .cache » perso…), il n'est jamais proposé.
REGEN_MARKERS = {
    "node_modules": ("package.json",), "bower_components": ("bower.json",),
    ".next": ("package.json",), ".nuxt": ("package.json",), ".parcel-cache": ("package.json",),
    ".turbo": ("package.json",),
    ".venv": ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg", "Pipfile"),
    "venv": ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg", "Pipfile"),
    ".tox": ("tox.ini", "pyproject.toml", "setup.py", "setup.cfg"),
    "Pods": ("Podfile",),
    ".gradle": ("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"),
}
ALWAYS_REGEN = {"__pycache__", ".pytest_cache", ".mypy_cache", "DerivedData"}


def _regen_verified(path: str) -> bool:
    name, parent = os.path.basename(path), os.path.dirname(path)
    if name in ALWAYS_REGEN:
        return True
    return any(os.path.exists(os.path.join(parent, m)) for m in REGEN_MARKERS.get(name, ()))


def _has_ancestor(path: str, chosen: set) -> bool:
    parts = path.split("/")
    return any("/".join(parts[:k]) in chosen for k in range(2, len(parts)))


def summary(idx: Index, sources: list[Source], reclaim: int) -> dict:
    per = {}
    for s in sources:
        d = idx.dirs.get(s.root) if s.present else None
        local = sum(f.size for f in idx.files if f.source == s.id and not f.dataless)
        per[s.id] = {
            "id": s.id, "label": s.label, "root": s.root, "present": s.present, "hint": s.hint,
            "size": d.size if d else 0, "files": d.files if d else 0,
            "local": local if d else 0, "cats": d.cats if d else {},
            "unlisted": getattr(idx, "unlisted", {}).get(s.id, 0),
        }
    return {"sources": list(per.values()), "scanned_at": idx.scanned_at,
            "errors": idx.errors, "reclaim": reclaim,
            "total": sum(p["size"] for p in per.values()),
            "files": sum(p["files"] for p in per.values())}


def _nfiles(n: int) -> str:
    return f"{n} fichier" if n == 1 else f"{n} fichiers"
