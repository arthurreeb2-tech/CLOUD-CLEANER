"""Lancement : python3 -m cloudcleaner [--port 8765] [--demo DOSSIER] [--no-open]"""
from __future__ import annotations

import argparse
import fcntl
import os
import socket
import sys
import threading
import urllib.request
import webbrowser

from . import demo as demo_mod
from . import scanner
from .server import App, serve

DEJA_OUVERT = 3


def main():
    ap = argparse.ArgumentParser(description="Nettoyage et rangement d'iCloud, Google Drive et OneDrive.")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--demo", metavar="DOSSIER",
                    help="mode démonstration sur de faux clouds créés dans DOSSIER")
    ap.add_argument("--no-open", action="store_true", help="ne pas ouvrir le navigateur")
    args = ap.parse_args()

    # Une instance tourne déjà sur ce port : on l'ouvre au lieu d'en lancer une seconde.
    port = args.port
    for port in range(args.port, args.port + 20):
        state = _port_state(port)
        if state == "cloudcleaner" and not args.demo:
            url = f"http://127.0.0.1:{port}"
            print(f"Cloud Cleaner tourne déjà : {url}")
            if not args.no_open:
                webbrowser.open(url)
            return
        if state == "free":
            break
    else:
        raise SystemExit("Aucun port libre trouvé. Précise-en un avec --port.")

    if args.demo:
        base = os.path.abspath(args.demo)
        data_dir = os.path.join(base, "_CloudCleaner")
    else:
        home = os.path.expanduser("~")
        data_dir = os.path.join(home, "CloudCleaner")
    # Verrou : une seule instance par dossier de données, quoi qu'il arrive.
    os.makedirs(data_dir, exist_ok=True)
    lock = open(os.path.join(data_dir, ".instance.lock"), "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("Cloud Cleaner est déjà ouvert : utilise la fenêtre existante.")
        sys.exit(DEJA_OUVERT)  # code distinct : le lanceur ne prend pas ça pour une panne

    if args.demo:
        sources = demo_mod.build(base)
        app = App(sources, data_dir, os.path.join(base, "_Archives-Cloud"), demo=True)
    else:
        app = App(scanner.detect_sources(home), data_dir, os.path.join(home, "Archives-Cloud"))
    # Mises à jour signées : seulement pour l'app installée (lancée par son lanceur).
    if os.environ.get("CC_LANCEUR") == "1" and (not args.demo or os.environ.get("CC_MAJ_URL")):
        app.maj.demarrer()
    if not args.no_open:
        threading.Timer(0.6, webbrowser.open, [f"http://127.0.0.1:{port}"]).start()
    serve(app, port)


def _port_state(port: int) -> str:
    """« free », « cloudcleaner » (instance déjà lancée) ou « busy » (autre programme)."""
    with socket.socket() as sock:
        sock.settimeout(0.5)
        if sock.connect_ex(("127.0.0.1", port)) != 0:
            return "free"
    # Sans proxy : un proxy système ne doit jamais cacher une instance déjà ouverte.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(f"http://127.0.0.1:{port}/", timeout=2) as resp:
            if b"<title>Cloud Cleaner</title>" in resp.read(4096):
                return "cloudcleaner"
    except OSError:
        pass
    return "busy"


if __name__ == "__main__":
    main()
