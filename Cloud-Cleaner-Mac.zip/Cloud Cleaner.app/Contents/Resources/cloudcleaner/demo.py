"""Faux clouds pour essayer l'application sans toucher aux vrais fichiers.

Les gros fichiers sont « creux » (taille déclarée, aucun espace disque occupé).
"""
from __future__ import annotations

import os
import time

from .scanner import Source

MB = 1024 * 1024
YEAR = 365.25 * 86400


def _mk(path: str, size: int = 0, age_years: float = 0.1, content: bytes | None = None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        if content is not None:
            fh.write(content)
        elif size:
            fh.write(os.path.basename(path).encode())  # contenu distinct par nom
            fh.truncate(size)
    t = time.time() - age_years * YEAR
    os.utime(path, (t, t))


def build(base: str) -> list[Source]:
    icloud = os.path.join(base, "iCloud Drive")
    docs = os.path.join(icloud, "com~apple~CloudDocs")
    gdrive = os.path.join(base, "Google Drive")
    onedrive = os.path.join(base, "OneDrive")
    sources = [Source("icloud", "iCloud Drive", icloud), Source("gdrive", "Google Drive", gdrive),
               Source("onedrive", "OneDrive", onedrive)]
    if os.path.isdir(icloud):
        return sources  # déjà créé

    same = b"contenu identique " * 20000  # ~360 Ko, vrai doublon
    # --- iCloud Drive
    _mk(os.path.join(icloud, "57T9237FN3~net~whatsapp~WhatsApp", "Backup", "chats.bak"), 900 * MB, 0.2)
    for i in range(14):
        ext = ["pdf", "jpg", "docx", "mov", "zip", "xlsx", "png"][i % 7]
        _mk(os.path.join(docs, f"fichier en vrac {i}.{ext}"), (3 + i) * MB, 0.3 + i * 0.2)
    _mk(os.path.join(docs, "Devis charpente.pdf"), content=same, age_years=0.5)
    _mk(os.path.join(docs, "Projets", "2025 Maison Muller", "Devis charpente copie.pdf"), content=same)
    _mk(os.path.join(docs, "Projets", "2025 Maison Muller", "plans.dwg"), 85 * MB, 0.4)
    _mk(os.path.join(docs, "Projets", "2025 Maison Muller", "visite chantier.mov"), 1400 * MB, 0.4)
    for i in range(30):
        _mk(os.path.join(docs, "Projets", "2019 Hangar", f"photo_{i:03}.jpg"), 6 * MB + i, 5.5)
    _mk(os.path.join(docs, "Projets", "2019 Hangar", "rendu final.mp4"), 2300 * MB, 5.4)
    _mk(os.path.join(docs, "Projets", "site-web", "node_modules", "lib", "index.js"), 240 * MB, 1)
    _mk(os.path.join(docs, "Projets", "site-web", "index.html"), 40 * 1024, 1)
    _mk(os.path.join(docs, "Projets", "site-web", "package.json"), content=b'{"name": "site"}',
        age_years=1)
    _mk(os.path.join(docs, "Perso", "venv", "photos-de-vacances.jpg"), 3 * MB, 1)  # pas un vrai venv
    for i in range(230):
        _mk(os.path.join(docs, "Scans", f"scan_{i:04}.pdf"), 400 * 1024 + i, 0.2 + (i % 20) / 10)
    _mk(os.path.join(docs, "Téléchargements", "Xcode_16.dmg"), 3100 * MB, 1.2)
    _mk(os.path.join(docs, "Téléchargements", "setup-cadwork.exe"), 780 * MB, 2.5)
    _mk(os.path.join(docs, "Téléchargements", "film.mkv.crdownload"), 420 * MB, 1.5)
    _mk(os.path.join(docs, "Nouveau dossier", "notes.txt"), 2048, 3)
    os.makedirs(os.path.join(docs, "Nouveau dossier (2)"), exist_ok=True)
    os.makedirs(os.path.join(docs, "Vide", "Encore vide"), exist_ok=True)
    for i in range(9):
        _mk(os.path.join(docs, "Desktop", f"Capture d’écran 2024-0{i + 1}-12 à 10.0{i}.png"),
            2 * MB + i, 2.2)
    _mk(os.path.join(docs, "Desktop", ".DS_Store"), 8196, 0.1)
    _mk(os.path.join(docs, "a", "b", "c", "d", "e", "f", "g", "h", "enfoui.txt"), 1024, 1)

    # --- Google Drive
    _mk(os.path.join(gdrive, "Mon Drive", "Devis charpente.pdf"), content=same, age_years=0.6)
    for y in (2017, 2018, 2019):
        for i in range(12):
            _mk(os.path.join(gdrive, "Mon Drive", "Photos", str(y), f"IMG_{y}{i:02}.heic"),
                4 * MB + i * 7 + y, 2026 - y)
    _mk(os.path.join(gdrive, "Mon Drive", "Photos", "2026", "IMG_0001.heic"), 5 * MB, 0.1)
    _mk(os.path.join(gdrive, "Mon Drive", "Compta", "~$bilan 2025.xlsx"), 165, 0.3)
    _mk(os.path.join(gdrive, "Mon Drive", "Compta", "bilan 2025.xlsx"), 2 * MB, 0.3)
    _mk(os.path.join(gdrive, "Mon Drive", "Compta", "bilan 2025 (1).xlsx"), 2 * MB + 9, 0.3)
    _mk(os.path.join(gdrive, "Mon Drive", "Sauvegardes", "backup-iphone.zip"), 5200 * MB, 3.2)
    _mk(os.path.join(gdrive, "Mon Drive", "Musique", "maquette.wav"), 310 * MB, 0.8)

    # --- OneDrive
    _mk(os.path.join(onedrive, "Documents", "Rapport annuel.docx"), 12 * MB, 0.2)
    _mk(os.path.join(onedrive, "Documents", "Rapport annuel - Copie.docx"), 12 * MB + 3, 0.2)
    _mk(os.path.join(onedrive, "Images", "Pellicule", "video anniversaire.mp4"), 1800 * MB, 4)
    for i in range(20):
        _mk(os.path.join(onedrive, "Images", "Pellicule", f"WP_{i:04}.jpg"), 3 * MB + i * 11, 4.1)
    _mk(os.path.join(onedrive, "Pièces jointes", "Thumbs.db"), 50 * 1024, 2)
    _mk(os.path.join(onedrive, "Pièces jointes", "presentation.pptx"), 45 * MB, 0.9)
    _mk(os.path.join(onedrive, "divers", "win11.iso"), 5400 * MB, 2.8)
    return sources
