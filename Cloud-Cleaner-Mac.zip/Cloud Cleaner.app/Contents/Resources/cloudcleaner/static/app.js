"use strict";
const TOKEN = document.querySelector('meta[name="token"]').content;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const CAT_LABEL = { images: "Images", videos: "Vidéos", audio: "Audio", documents: "Documents",
  archives: "Archives", code: "Code", installateurs: "Installateurs", "3d_cao": "3D et CAO", autres: "Autres" };
// Une seule action par type de recommandation, avec des mots simples.
const ACTIONS = {
  quarantine: { btn: "Mettre à la corbeille Cloud Cleaner", title: "Mettre à la corbeille Cloud Cleaner ?",
    what: (p) => `${p ? "seront retirés" : "sera retiré"} du cloud (donc aussi de tes autres appareils) et ${p ? "mis" : "mis"} de côté dans la corbeille de Cloud Cleaner, sur ce Mac. Rien n'est effacé : tu peux tout remettre en place.` },
  archive: { btn: "Déplacer sur ce Mac seulement", title: "Déplacer sur ce Mac seulement ?",
    what: (p) => `${p ? "quitteront" : "quittera"} le cloud et ${p ? "seront rangés" : "sera rangé"} sur ce Mac, dans le dossier Archives-Cloud. ${p ? "Ils ne seront" : "Il ne sera"} plus visible${p ? "s" : ""} sur tes autres appareils. Tu peux tout remettre en place.` },
  organize: { btn: "Ranger par type", title: "Ranger par type ?",
    what: (p) => `${p ? "seront rangés" : "sera rangé"} dans des dossiers par type (Docs, Images, Vidéos…), dans le même cloud. Tu peux tout remettre en place.` },
};
const JOB_TITLE = { quarantine: "Mise à la corbeille", archive: "Déplacement sur ce Mac", organize: "Rangement",
  restore: "Remise en place", purge: "Suppression définitive" };
const OP_LABEL = { quarantine: "Mis à la corbeille Cloud Cleaner", archive: "Déplacé sur ce Mac (Archives-Cloud)", organize: "Rangé par type" };
const TRASH_LINKS = {
  icloud: ["iCloud Drive : « Récemment supprimés »", "https://www.icloud.com/iclouddrive/"],
  gdrive: ["Google Drive : « Corbeille »", "https://drive.google.com/drive/trash"],
  onedrive: ["OneDrive : « Corbeille »", "https://onedrive.live.com/"],
};
const MARGIN = 1024 ** 3; // marge d'espace libre gardée sur le Mac

let S = { state: null, recos: [], journal: [], tab: "home", catOrder: [] };

async function api(path, body) {
  const opt = { headers: { "X-Token": TOKEN } };
  if (body !== undefined) {
    opt.method = "POST";
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  const r = await fetch(path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Erreur ${r.status}`);
  return data;
}

function fmtSize(b) {
  if (!b) return "0 o";
  const u = ["o", "Ko", "Mo", "Go", "To"];
  let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b >= 100 || i === 0 ? Math.round(b) : b.toFixed(1).replace(".", ",")} ${u[i]}`;
}
const fmtNum = (n) => Number(n || 0).toLocaleString("fr-FR");
const fmtDate = (t) => t ? new Date(t * 1000).toLocaleDateString("fr-FR", { year: "numeric", month: "short", day: "numeric" }) : "";
const fmtDateTime = (t) => new Date(t * 1000).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short" });
const plural = (n, one, many) => `${fmtNum(n)} ${n > 1 ? many : one}`;

function shortPath(p) {
  for (const s of S.state?.sources || []) {
    if (p === s.root || p.startsWith(s.root + "/")) {
      return (s.label + p.slice(s.root.length)).replace("/com~apple~CloudDocs", "");
    }
  }
  return p;
}
const dirOf = (p) => p.slice(0, p.lastIndexOf("/"));
const firstSentence = (t) => (t.match(/^.*?[.!?](?=\s|$)/) || [t])[0];

function toast(msg, ms = 5000) {
  const t = $("#toast");
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), ms);
}
// okLabel null : simple message d'information (un seul bouton « Compris »).
function confirmModal(title, html, okLabel, danger = false) {
  if ($("#modal").open) return Promise.resolve(false);  // double clic : une seule fenêtre
  return new Promise((res) => {
    const m = $("#modal");
    $("#modalTitle").textContent = title;
    $("#modalBody").innerHTML = html;
    const ok = $("#modalOk"), cancel = $("#modalCancel");
    ok.hidden = !okLabel;
    ok.textContent = okLabel || "";
    ok.className = "btn " + (danger ? "danger" : "primary");
    cancel.textContent = okLabel ? "Pas maintenant" : "Compris";
    m.onclose = () => res(m.returnValue === "ok");
    m.returnValue = "cancel";
    m.showModal();
  });
}

// ---------- infobulle ----------
const tip = $("#tooltip");
document.addEventListener("mousemove", (e) => {
  const el = e.target.closest?.("[data-tip]");
  if (!el) { tip.hidden = true; return; }
  tip.textContent = el.dataset.tip; tip.hidden = false;
  tip.style.left = Math.min(e.clientX + 12, innerWidth - tip.offsetWidth - 8) + "px";
  tip.style.top = e.clientY + 14 + "px";
});

// ---------- composants ----------
function catBar(cats, total) {
  const segs = S.catOrder.filter((c) => cats[c] > 0).map((c) =>
    `<span style="flex:${cats[c]};background:var(--c-${c})" data-tip="${esc(CAT_LABEL[c])} : ${fmtSize(cats[c])} (${Math.round(cats[c] / total * 100)} %)"></span>`);
  return `<div class="bar">${segs.join("")}</div>`;
}
function legend(cats) {
  return S.catOrder.filter((c) => !cats || cats[c] > 0).map((c) =>
    `<span><i style="background:var(--c-${c})"></i>${esc(CAT_LABEL[c])}</span>`).join("");
}

// ---------- sélection (gardée d'une analyse à l'autre) ----------
const sel = new Map();        // id reco -> Set(chemins cochés)
const overrides = new Map();  // « id reco|chemin » -> choix explicite de l'utilisateur
const okey = (r, p) => `${r.id}|${p}`;
const recoItems = (r) => r.groups.length ? r.groups.flatMap((g) => g.items) : r.items;
const actionable = (r) => r.action !== "info";

function defaultOn(r, i, g) { return r.checked && !i.keep && (!g || g.certain); }
function initSel() {
  sel.clear();
  for (const r of S.recos) {
    const set = new Set();
    if (actionable(r)) {
      const visit = (i, g) => {
        if (i.keep) return;
        const k = okey(r, i.path);
        const on = overrides.has(k) ? overrides.get(k) : defaultOn(r, i, g);
        if (on) set.add(i.path);
      };
      if (r.groups.length) r.groups.forEach((g) => g.items.forEach((i) => visit(i, g)));
      else r.items.forEach((i) => visit(i));
    }
    sel.set(r.id, set);
  }
}
function setOn(r, path, on) {
  overrides.set(okey(r, path), on);
  on ? sel.get(r.id).add(path) : sel.get(r.id).delete(path);
}
function selected(r) { const s = sel.get(r.id); return recoItems(r).filter((i) => s.has(i.path)); }
const sum = (items, k = "size") => items.reduce((a, i) => a + (i[k] || 0), 0);
const jobBusy = () => ["running", "finalizing"].includes(S.state?.job?.state);
const scanBusy = () => ["scanning", "analyzing"].includes(S.state?.progress?.state);

// ---------- accueil ----------
function sourceCards(compact) {
  const sum_ = S.state.summary;
  return S.state.sources.map((s) => {
    if (!s.present) {
      return `<div class="card src absent"><h3>${esc(s.label)} <span class="badge">pas trouvé</span></h3>
        <p class="muted" style="margin-top:8px">${esc(s.hint)} Ensuite, relance l'analyse avec le bouton en haut à droite.</p></div>`;
    }
    if (!sum_) return `<div class="card src"><h3>${esc(s.label)} <span class="badge keep">trouvé</span></h3>
        <p class="muted" style="margin-top:8px">Prêt à être analysé.</p></div>`;
    const online = s.size - s.local;
    return `<div class="card src"><h3>${esc(s.label)}<span class="muted num" style="font-weight:400;font-size:12px">${plural(s.files, "fichier", "fichiers")}</span></h3>
      <div class="size num">${fmtSize(s.size)}</div>
      <div class="muted small">${fmtSize(s.local)} téléchargés sur ce Mac · ${fmtSize(online)} restés dans le cloud</div>
      ${!compact && s.size ? catBar(s.cats, s.size) + `<div class="legend">${legend(s.cats)}</div>` : ""}
      ${s.unlisted ? `<p class="badge warn" style="margin-top:10px;white-space:normal">${esc(s.label)} a répondu trop lentement : ${plural(s.unlisted, "dossier n'a pas pu être lu", "dossiers n'ont pas pu être lus")}. Vérifie que l'app ${esc(s.label)} est ouverte et connectée, puis relance l'analyse.</p>` : ""}</div>`;
  }).join("");
}

function renderHome() {
  const el = $("#tab-home");
  const st = S.state, sm = st.summary;
  if (!sm) {
    el.innerHTML = `<div class="card empty"><h2>Faire de la place dans tes clouds</h2>
      <p>Je regarde les noms, tailles et dates de tes fichiers. Rien n'est téléchargé, rien ne quitte ce Mac, rien n'est modifié sans ton accord.</p>
      <button class="btn primary big" id="scanBtn2" ${scanBusy() ? "disabled" : ""}>Analyser mes clouds</button></div>
      <div class="section-title">Clouds trouvés sur ce Mac</div><div class="grid">${sourceCards(true)}</div>`;
    $("#scanBtn2").onclick = startScan;
    return;
  }
  // Doublons sans aucun groupe vérifié : rien de sûr à cocher, ils vont dans « À décider ».
  const safe = S.recos.filter((r) => r.safe && actionable(r) && (!r.groups.length || r.groups.some((g) => g.certain)));
  const decide = S.recos.filter((r) => !r.safe && actionable(r));
  const probable = (S.recos.find((r) => r.id === "doublons")?.groups || []).filter((g) => !g.certain);
  const rows = safe.map((r) => {
    const s = selected(r);
    const eligible = r.groups.length ? r.groups.filter((g) => g.certain).reduce((a, g) => a + g.items.length - 1, 0)
      : r.items.length;
    return `<label class="safe-row">
      <input type="checkbox" data-cat="${esc(r.id)}" data-partial="${s.length && s.length < eligible ? 1 : 0}" ${s.length ? "checked" : ""} aria-label="${esc(r.title)}">
      <div class="t"><b>${esc(r.title)}</b><div class="muted">${esc(firstSentence(r.why))}</div></div>
      <div class="g num">${s.length ? `${fmtSize(sum(s))}<div class="muted small">${plural(s.length, "élément", "éléments")}</div>`
        : `<span class="muted">${fmtSize(r.gain)}</span><div class="muted small">non coché</div>`}</div>
      <button type="button" class="link" data-goto="${esc(r.id)}">Voir la liste</button></label>`;
  }).join("");
  const decideRows = decide.map((r) => `<div class="reco-row"><div class="t"><b>${esc(r.title)}</b><div class="muted">${esc(firstSentence(r.why))}</div></div>
      <div class="g num">${fmtSize(r.gain)}</div><button class="btn small" data-goto="${esc(r.id)}">Choisir…</button></div>`).join("")
    + (probable.length ? `<div class="reco-row"><div class="t"><b>Doublons à vérifier</b><div class="muted">Même nom et même taille, mais contenu pas comparable car pas téléchargé sur ce Mac.</div></div>
      <div class="g num">${plural(probable.length, "groupe", "groupes")}</div><button class="btn small" data-goto="doublons">Choisir…</button></div>` : "");
  const live = S.journal.filter((o) => o.status === "done" && o.count);
  const inBin = live.filter((o) => o.type === "quarantine");
  const binSize = sum(inBin);
  const lastOp = live[0];
  const trash = st.sources.filter((s) => s.present).map((s) => {
    const l = TRASH_LINKS[s.id.replace(/\d+$/, "")];
    return l ? `<a href="${l[1]}" target="_blank" rel="noopener">${esc(l[0])}</a>` : "";
  }).join(" · ");
  const cats = {};
  st.sources.forEach((s) => Object.entries(s.cats || {}).forEach(([k, v]) => (cats[k] = (cats[k] || 0) + v)));
  const catRows = S.catOrder.filter((c) => cats[c] > 0).sort((a, b) => cats[b] - cats[a]).map((c) =>
    `<tr><td><i style="background:var(--c-${c})"></i>${esc(CAT_LABEL[c])}</td><td class="num">${fmtSize(cats[c])}</td>
     <td class="num muted" style="width:60px">${Math.round(cats[c] / sm.total * 100)} %</td></tr>`).join("");

  el.innerHTML = `<div class="card hero-clean">
      <div class="hero-head">
        <div><div class="label">Je peux libérer sans risque</div><div class="amount num" id="homeTotal">0 o</div>
          <div class="muted">sur ${fmtSize(sm.total)} utilisés dans tes clouds · analyse du ${fmtDateTime(sm.scanned_at)}${st.demo ? " · <span class='badge warn'>démonstration : faux clouds</span>" : ""}</div></div>
        <div class="hero-cta"><button class="btn primary big" id="cleanBtn">Nettoyer</button>
          <div class="muted small">Rien n'est effacé : tout reste récupérable.</div></div>
      </div>
      ${safe.length ? `<div class="safe-list">${rows}</div>` : '<p class="muted">Rien à nettoyer sans risque pour l\'instant. Regarde « À décider toi-même » ci-dessous.</p>'}
    </div>
    ${inBin.length || lastOp ? `<div class="card bin">
      <h3>Corbeille Cloud Cleaner</h3>
      <p>${inBin.length ? `<b>${fmtSize(binSize)}</b> mis de côté sur ce Mac. Tant que tu ne vides pas cette corbeille, tout peut être remis en place.` : "La corbeille est vide."}</p>
      <div class="row-btns">
        ${lastOp ? `<button class="btn" data-restore="${esc(lastOp.id)}">Annuler la dernière opération</button>` : ""}
        ${inBin.length ? `<button class="btn danger" id="emptyBin">Vider la corbeille (${fmtSize(binSize)})</button>` : ""}
      </div>
      ${trash ? `<p class="muted small" style="margin-top:10px">Pour récupérer l'espace en ligne, vide aussi la corbeille de chaque service (l'espace n'est parfois rendu qu'à ce moment-là) : ${trash}</p>` : ""}
    </div>` : ""}
    ${decideRows ? `<div class="section-title">À décider toi-même</div><div class="card">${decideRows}</div>` : ""}
    <div class="section-title">Tes clouds</div><div class="grid">${sourceCards(false)}</div>
    <div class="section-title">Ce qui prend de la place</div>
    <div class="card"><table class="cat-table">${catRows}</table></div>`;
  updateHomeTotal();
  $$("[data-partial='1']", el).forEach((cb) => (cb.indeterminate = true));
  $$("[data-cat]", el).forEach((cb) => (cb.onchange = () => {
    const r = S.recos.find((x) => x.id === cb.dataset.cat);
    if (r.groups.length) r.groups.forEach((g) => g.items.forEach((i) => !i.keep && setOn(r, i.path, cb.checked && g.certain)));
    else r.items.forEach((i) => setOn(r, i.path, cb.checked));
    renderHome(); renderRecos();
  }));
  $$("[data-goto]", el).forEach((b) => (b.onclick = (e) => { e.preventDefault(); showTab("recos"); openReco(b.dataset.goto); }));
  $("#cleanBtn").onclick = cleanSafe;
  bindRestore(el);
  const eb = $("#emptyBin");
  if (eb) eb.onclick = () => emptyBin(inBin);
}
// « Nettoyer » ne prend que le sûr : pour les doublons, seulement les groupes vérifiés
// (un doublon « à vérifier » coché dans Détails se traite depuis Détails).
function safeSelection() {
  return S.recos.filter((r) => r.safe && actionable(r)).map((r) => {
    const sure = r.groups.length ? new Set(r.groups.filter((g) => g.certain).flatMap((g) => g.items.map((i) => i.path))) : null;
    return { r, items: selected(r).filter((i) => !sure || sure.has(i.path)) };
  }).filter((x) => x.items.length);
}
function updateHomeTotal() {
  const items = safeSelection().flatMap((x) => x.items);
  const t = sum(items);
  const el = $("#homeTotal");
  if (el) el.textContent = fmtSize(t);
  const b = $("#cleanBtn");
  if (b) {
    b.textContent = !items.length ? "Nettoyer" : t ? `Nettoyer (${fmtSize(t)})` : `Nettoyer (${plural(items.length, "élément", "éléments")})`;
    b.disabled = !items.length || jobBusy() || scanBusy();
    b.title = !items.length ? "Coche au moins une ligne" : "";
  }
}

async function cleanSafe() {
  const parts = safeSelection();
  const items = parts.flatMap((x) => x.items);
  if (!items.length) return;
  const ok = await confirmAction("quarantine", items,
    `<ul class="plain">${parts.map((x) => `<li>${esc(x.r.title)} : ${plural(x.items.length, "élément", "éléments")}, ${fmtSize(sum(x.items))}</li>`).join("")}</ul>`);
  if (ok) launch({ type: "quarantine", paths: items.map((i) => i.path) });
}

// Confirmation commune : quoi, combien, place nécessaire sur le Mac.
async function confirmAction(type, items, extra = "") {
  const size = sum(items), online = sum(items, "online");
  const free = S.state.free_space;
  if (type !== "organize" && online && free !== null && online > free - MARGIN) {
    await confirmModal("Pas assez de place sur ce Mac",
      `<p>${fmtSize(online)} de ces fichiers sont restés dans le cloud : il faut d'abord les télécharger sur ce Mac, qui n'a que ${fmtSize(free)} de libre.</p>
       <p style="margin-top:8px">Sélectionne moins d'éléments, ou fais de la place sur le Mac, puis réessaie.</p>`, null);
    return false;
  }
  const chosen = new Set(items.map((i) => i.path));
  const keepAll = S.recos.some((r) => r.groups.some((g) => g.items.every((i) => chosen.has(i.path))));
  return confirmModal(ACTIONS[type].title,
    `<p><b>${plural(items.length, "élément", "éléments")}</b> (${fmtSize(size)}) ${ACTIONS[type].what(items.length > 1)}</p>${extra}
     ${online && type !== "organize" ? `<p class="warn-line">${fmtSize(online)} sont restés dans le cloud et vont d'abord être téléchargés sur ce Mac (${fmtSize(free)} libres).</p>` : ""}
     ${keepAll ? `<p class="warn-line danger">Attention : pour au moins un fichier, tous les exemplaires sont cochés. Il n'en restera aucun dans le cloud.</p>` : ""}`,
    ACTIONS[type].btn);
}

async function launch(body) {
  try {
    await api("/api/action", body);
    dismissedJob = null;
    S.state.job = { state: "running", type: body.type, total: 0, done: 0, bytes: 0, started: Date.now() / 1000, id: "?" };
    poll();
  } catch (e) { toast(e.message); }
}

// ---------- détails ----------
const shownCount = new Map();

function itemRow(r, i) {
  const s = sel.get(r.id);
  const cb = !actionable(r) || i.keep ? `<span class="keep-dot" ${i.keep ? 'data-tip="Exemplaire gardé"' : ""}></span>`
    : `<input type="checkbox" data-path="${esc(i.path)}" ${s.has(i.path) ? "checked" : ""} aria-label="Sélectionner ${esc(i.name)}">`;
  const badges = [
    i.keep ? '<span class="badge keep">gardé</span>' : "",
    i.online ? `<span class="badge" data-tip="Dans le cloud, pas encore téléchargé sur ce Mac (${fmtSize(i.online)})">pas sur ce Mac</span>` : "",
    i.kind === "dir" || i.kind === "regen" || i.kind === "bundle" ? '<span class="badge">dossier</span>' : "",
    i.note ? `<span class="badge">${esc(i.note)}</span>` : "",
  ].join(" ");
  return `<label class="item">${cb}<div class="n"><b>${esc(i.name)} ${badges}</b><small>${esc(shortPath(dirOf(i.path)))}</small></div>
    <div class="s num">${i.size ? fmtSize(i.size) : ""}</div><div class="d">${fmtDate(i.mtime)}</div>
    <button type="button" class="icon-btn" data-reveal="${esc(i.path)}" data-tip="Afficher dans le Finder" aria-label="Afficher dans le Finder">↗</button></label>`;
}

function fillReco(d, r) {
  const s = sel.get(r.id);
  const isGroups = r.groups.length > 0;
  const total = isGroups ? r.groups.length : r.items.length;
  const lim = Math.min(total, shownCount.get(r.id) || (isGroups ? 30 : 80));
  let list;
  if (isGroups) {
    list = r.groups.slice(0, lim).map((g) => `<div class="group"><div class="group-head">
        <span class="badge ${g.certain ? "keep" : "warn"}">${g.certain ? "identiques" : "à vérifier"}</span>
        ${g.cross ? '<span class="badge">dans plusieurs clouds</span>' : ""}
        <span>${g.items.length} exemplaires · ${fmtSize(g.gain)} à gagner</span></div>
        <div class="items">${g.items.map((i) => itemRow(r, i)).join("")}</div></div>`).join("");
  } else {
    list = `<div class="items">${r.items.slice(0, lim).map((i) => itemRow(r, i)).join("")}</div>`;
  }
  const more = (total > lim ? `<div class="more"><button type="button" class="btn small" data-more>Afficher la suite (${fmtNum(total - lim)})</button></div>` : "")
    + (r.count > total ? `<div class="more">La liste s'arrête à ${fmtNum(total)} ${isGroups ? "groupes" : "éléments"} sur ${fmtNum(r.count)}. Traite-les puis relance l'analyse pour voir la suite.</div>` : "");
  const tools = actionable(r) ? `<div class="toolbar"><span class="sel" data-sel></span>
      <button type="button" class="link" data-all="1">Tout cocher</button><button type="button" class="link" data-all="0">Tout décocher</button>
      <button type="button" class="btn primary" data-act="${r.action}">${ACTIONS[r.action].btn}</button></div>` : "";
  const body = $(".reco-body", d);
  body.innerHTML = `<p class="why">${esc(r.why)}</p>${tools}${list}${more}`;
  d.dataset.filled = "1";
  const visible = new Set(recoItems(r).slice(0, isGroups ? Infinity : lim).map((i) => i.path));
  if (isGroups) { visible.clear(); r.groups.slice(0, lim).forEach((g) => g.items.forEach((i) => visible.add(i.path))); }
  const upd = () => {
    const lab = $("[data-sel]", d);
    if (!lab) return;
    const items = selected(r);
    const hidden = items.filter((i) => !visible.has(i.path)).length;
    lab.innerHTML = `${plural(items.length, "élément choisi", "éléments choisis")} · ${fmtSize(sum(items))}` +
      (hidden ? ` <span class="warn-inline">dont ${fmtNum(hidden)} plus bas dans la liste</span>` : "");
    $$("[data-act]", d).forEach((b) => {
      b.disabled = !items.length || jobBusy() || scanBusy();
      b.title = jobBusy() ? "Une opération est en cours" : !items.length ? "Coche au moins un élément" : "";
    });
  };
  upd();
  body.onchange = (e) => {
    const p = e.target.dataset?.path;
    if (!p) return;
    setOn(r, p, e.target.checked);
    upd(); if (r.safe) renderHome();
  };
  body.onclick = async (e) => {
    const t = e.target.closest("button");
    if (!t) return;
    e.preventDefault();
    if (t.dataset.reveal) reveal(t.dataset.reveal);
    else if (t.dataset.more !== undefined) { shownCount.set(r.id, lim + (isGroups ? 60 : 200)); fillReco(d, r); }
    else if (t.dataset.all) {
      recoItems(r).forEach((i) => !i.keep && setOn(r, i.path, t.dataset.all === "1"));
      $$("input[data-path]", d).forEach((c) => (c.checked = s.has(c.dataset.path)));
      upd(); if (r.safe) renderHome();
    } else if (t.dataset.act) {
      const items = selected(r);
      if (!items.length) return;
      if (await confirmAction(r.action, items)) {
        launch(r.action === "organize"
          ? { type: "organize", moves: items.map((i) => ({ path: i.path, dest: i.dest })) }
          : { type: r.action, paths: items.map((i) => i.path) });
      }
    }
  };
}

function renderRecos() {
  const el = $("#tab-recos");
  const open = new Set($$("details.reco[open]", el).map((d) => d.dataset.id));
  if (!S.state.summary) { el.innerHTML = '<div class="card empty"><p>Lance d\'abord une analyse depuis l\'Accueil.</p></div>'; return; }
  if (!S.recos.length) { el.innerHTML = '<div class="card empty"><h2>Rien à signaler</h2><p>Tes clouds sont propres.</p></div>'; return; }
  const block = (r) => `<details class="reco" data-id="${esc(r.id)}" ${open.has(r.id) ? "open" : ""}>
      <summary><h3>${esc(r.title)}</h3><span class="muted num">${plural(r.count, r.groups.length ? "groupe" : "élément", r.groups.length ? "groupes" : "éléments")}</span>
      ${actionable(r) && r.gain ? `<span class="gain num">${fmtSize(r.gain)}</span>` : ""}</summary>
      <div class="reco-body"></div></details>`;
  const clean = S.recos.filter((r) => r.level !== "structure");
  const struct = S.recos.filter((r) => r.level === "structure");
  el.innerHTML = `<p class="intro">Tout ce que l'analyse a trouvé, élément par élément. Clique sur une ligne pour la déplier, coche ce que tu veux traiter, puis utilise le bouton de la carte.</p>
    ${clean.length ? '<div class="section-title" style="margin-top:0">Pour faire de la place</div>' + clean.map(block).join("") : ""}
    ${struct.length ? '<div class="section-title">Conseils de rangement</div>' + struct.map(block).join("") : ""}`;
  $$("details.reco", el).forEach((d) => {
    const r = S.recos.find((x) => x.id === d.dataset.id);
    if (d.open) fillReco(d, r);
    d.addEventListener("toggle", () => { if (d.open && !d.dataset.filled) fillReco(d, r); });
  });
}

function openReco(id) {
  const d = $(`details.reco[data-id="${CSS.escape(id)}"]`);
  if (d) { d.open = true; setTimeout(() => d.scrollIntoView({ behavior: "smooth", block: "start" }), 50); }
}

// ---------- opération en cours ----------
let dismissedJob = null;

function renderJob() {
  const j = S.state.job, box = $("#job");
  // Une opération terminée depuis longtemps (page rouverte) n'a plus à s'afficher.
  const stale = j && j.ended && Date.now() / 1000 - j.ended > 120;
  if (!j || j.id === dismissedJob || stale) { box.hidden = true; return false; }
  box.hidden = false;
  const busy = jobBusy();
  const pct = j.total ? Math.round(j.done / j.total * 100) : 0;
  const elapsed = Math.max(1, (j.ended || Date.now() / 1000) - j.started);
  const left = busy && j.done > 2 ? Math.round(elapsed / j.done * (j.total - j.done)) : null;
  const eta = left === null ? "" : left < 60 ? ` · environ ${left} s restantes` : ` · environ ${Math.round(left / 60)} min restantes`;
  const countTxt = `${fmtNum(j.done)} / ${fmtNum(j.total)} · ${fmtSize(j.bytes)}${eta}`;
  const key = `${j.id}|${j.state}|${!!j.cancelling}`;
  if (j.state === "running" && box.dataset.key === key) {  // seuls les chiffres changent
    $(".j-pct", box).textContent = `${pct} %`;
    $(".pbar i", box).style.width = `${pct}%`;
    $(".j-count", box).textContent = countTxt;
    $(".cur", box).textContent = shortPath(j.current) || "Préparation…";
    return true;
  }
  box.dataset.key = key;
  let head, detail = "", actions = "";
  if (j.state === "running") {
    head = `${JOB_TITLE[j.type]} en cours`;
    detail = `<div class="cur">${esc(shortPath(j.current)) || "Préparation…"}</div>`;
    actions = j.type === "purge" ? "" : j.cancelling ? '<span class="muted">Arrêt après le fichier en cours…</span>' : '<button class="btn small" id="jobStop">Arrêter</button>';
  } else if (j.state === "finalizing") {
    head = "Mise à jour de l'analyse"; detail = '<div class="cur">Presque terminé…</div>';
  } else if (j.state === "error") {
    head = "L'opération a échoué"; detail = `<div class="cur err">${esc(j.error)}</div>`;
    actions = '<button class="btn small" id="jobClose">Fermer</button>';
  } else {
    const n = plural(j.moved, "élément", "éléments");
    const done = { quarantine: `C'est fait : ${n} mis à la corbeille Cloud Cleaner (${fmtSize(j.size)}).`,
      archive: `C'est fait : ${n} déplacés sur ce Mac (${fmtSize(j.size)}).`,
      organize: `C'est fait : ${n} rangés.`, restore: `C'est fait : ${n} remis à leur place.`,
      purge: `C'est fait : ${fmtSize(j.size)} supprimés définitivement de ce Mac.` }[j.type];
    head = j.cancelled ? `${JOB_TITLE[j.type]} arrêtée` : "Terminé";
    const errs = (j.errors || []).slice(0, 3).map((e) => `<div class="cur err" data-tip="${esc(e.error)}">${esc((e.path || "").split("/").pop())} : ${esc(e.error)}</div>`).join("");
    detail = `<div class="cur wrap">${done}${j.failed ? ` ${plural(j.failed, "élément n'a pas pu être traité", "éléments n'ont pas pu être traités")}.` : ""}</div>${errs}
      ${j.type === "quarantine" && j.moved ? '<div class="cur wrap muted">Pour récupérer l\'espace en ligne, pense aussi à vider la corbeille de chaque service (voir l\'Accueil).</div>' : ""}`;
    actions = (j.op_id ? `<button class="btn small" data-restore="${esc(j.op_id)}">Tout remettre comme avant</button>` : "")
      + '<button class="btn small" id="jobClose">Fermer</button>';
  }
  box.className = "job" + (busy ? "" : j.state === "error" || j.failed ? " warn" : " ok");
  box.innerHTML = `<div class="job-head"><b>${esc(head)}</b>${busy ? `<span class="num j-pct">${pct} %</span>` : ""}</div>
    <div class="pbar${j.state === "finalizing" ? " indet" : ""}" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${busy ? pct : 100}%"></i></div>
    ${j.state === "running" ? `<div class="muted num j-count">${countTxt}</div>` : ""}
    ${detail}<div class="job-actions">${actions}</div>`;
  const on = (id, fn) => { const b = $("#" + id); if (b) b.onclick = fn; };
  on("jobStop", async () => { try { await api("/api/job/cancel", {}); } catch (e) { toast(e.message); } });
  on("jobClose", () => { dismissedJob = j.id; box.hidden = true; });
  bindRestore(box);
  return busy;
}

async function reveal(path) {
  try { await api("/api/reveal", { path }); } catch (e) { toast(e.message); }
}

function bindRestore(root) {
  $$("[data-restore]", root).forEach((b) => (b.onclick = async () => {
    if (jobBusy() || scanBusy()) return toast("Attends la fin de l'opération en cours.");
    const o = S.journal.find((x) => x.id === b.dataset.restore);
    const ok = await confirmModal("Tout remettre comme avant ?",
      `<p>${o ? `<b>${plural(o.count, "élément", "éléments")}</b> (${fmtSize(o.size)}) vont` : "Les éléments vont"} retrouver leur place d'origine dans le cloud.</p>
       <p style="margin-top:8px">L'analyse sera ensuite mise à jour automatiquement.</p>`, "Tout remettre");
    if (ok) {
      try { await api("/api/restore", { op: b.dataset.restore }); dismissedJob = null; poll(); } catch (e) { toast(e.message); }
    }
  }));
}

async function emptyBin(ops) {
  if (jobBusy() || scanBusy()) return toast("Attends la fin de l'opération en cours.");
  const size = sum(ops), count = ops.reduce((a, o) => a + o.count, 0);
  const ok = await confirmModal("Vider la corbeille Cloud Cleaner ?",
    `<p><b>${plural(count, "élément", "éléments")}</b> (${fmtSize(size)}) seront effacés définitivement de ce Mac. Les éventuelles copies de sécurité (opération interrompue) sont toujours gardées.</p>
     <p class="warn-line danger">Cette action ne peut pas être annulée.</p>`, "Vider définitivement", true);
  if (!ok) return;
  for (const o of ops) {  // une opération à la fois
    try {
      await api("/api/purge", { op: o.id, confirm: "SUPPRIMER" });
      dismissedJob = null;
      await waitJob();
    } catch (e) { toast(e.message); break; }
  }
  await refresh();
}
async function waitJob() {
  for (;;) {
    S.state = await api("/api/state");
    renderProgress();
    if (!jobBusy()) return;
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ---------- historique ----------
function renderJournal() {
  const el = $("#tab-journal");
  if (!S.journal.length) { el.innerHTML = '<div class="card empty"><h2>Historique vide</h2><p>Chaque nettoyage apparaîtra ici, avec un bouton pour tout remettre comme avant.</p></div>'; return; }
  const status = { restored: "remis en place", purged: "supprimé définitivement" };
  el.innerHTML = `<p class="intro">Chaque opération peut être annulée tant qu'elle n'a pas été supprimée définitivement.</p>` +
    S.journal.map((o) => `<div class="card op"><div class="t"><b>${esc(OP_LABEL[o.type] || o.type)}</b>
        ${o.status !== "done" ? `<span class="badge">${status[o.status] || esc(o.status)}</span>` : ""}
        ${o.cancelled ? '<span class="badge">arrêté en cours</span>' : ""}
        <div class="muted">${fmtDateTime(o.date)} · ${plural(o.count, "élément", "éléments")} · ${fmtSize(o.size)}</div>
        <div class="muted small">${o.items.map((i) => esc(shortPath(i.src))).join("<br>")}${o.count > o.items.length ? `<br>… et ${fmtNum(o.count - o.items.length)} autres` : ""}</div></div>
      ${o.status === "done" && o.count ? `${o.items[0] ? `<button class="btn small" data-reveal="${esc(o.items[0].dst)}">Voir sur le Mac</button>` : ""}
        <button class="btn" data-restore="${esc(o.id)}">Tout remettre comme avant</button>
        ${o.type === "quarantine" ? `<button class="btn danger small" data-purge="${esc(o.id)}">Supprimer définitivement</button>` : ""}` : ""}</div>`).join("");
  $$("[data-reveal]", el).forEach((b) => (b.onclick = () => reveal(b.dataset.reveal)));
  bindRestore(el);
  $$("[data-purge]", el).forEach((b) => (b.onclick = () => emptyBin([S.journal.find((x) => x.id === b.dataset.purge)])));
}

// ---------- carte des dossiers ----------
const G = { nodes: new Map(), root: null, sel: null, tx: 40, ty: 0, k: 1, total: 1, fitted: false };
const ROW = 30, COL = 230;

async function loadNode(path) {
  const data = await api("/api/tree?path=" + encodeURIComponent(path));
  const n = G.nodes.get(path) || { expanded: false };
  Object.assign(n, { data, loaded: true });
  G.nodes.set(path, n);
  for (const c of data.children) if (!G.nodes.has(c.path)) G.nodes.set(c.path, { data: c, expanded: false, loaded: false });
  return n;
}
async function initGraph() {
  G.nodes.clear(); G.sel = null; G.fitted = false; G.root = null;
  if (!S.state.summary) { $("#graphG").innerHTML = ""; return; }
  G.root = await loadNode("");
  G.root.expanded = true;
  G.total = G.root.data.size || 1;
  for (const c of G.root.data.children) { const n = await loadNode(c.path); n.expanded = true; }
  for (const c of G.root.data.children) {  // iCloud : ouvre directement « Mes fichiers »
    const docs = G.nodes.get(c.path).data.children.find((x) => x.name === "Mes fichiers");
    if (docs) { (await loadNode(docs.path)).expanded = true; }
  }
  $("#graphLegend").innerHTML = legend(null) + '<span class="muted">· taille du cercle = poids du dossier</span>';
  if (S.tab === "graph") drawGraph();
}
function layout() {
  const out = [], links = [];
  let row = 0;
  const walk = (n, depth) => {
    const d = n.data;
    const item = { n, d, depth, x: depth * COL, y: 0, pseudo: false };
    const kids = [];
    if (n.expanded && n.loaded) {
      for (const c of d.children) kids.push(walk(G.nodes.get(c.path), depth + 1));
      const pseudo = (name, o, cat) => {
        const p = { pseudo: true, depth: depth + 1, x: (depth + 1) * COL, y: row++ * ROW,
          d: { name, size: o.size, cat, path: null } };
        out.push(p); kids.push(p);
      };
      if (d.others) pseudo(`${fmtNum(d.others.count)} autres dossiers`, d.others, "autres");
      if (d.loose && d.path) pseudo(`${fmtNum(d.loose.count)} fichiers ici`, d.loose, d.cat);
    }
    item.y = kids.length ? (kids[0].y + kids[kids.length - 1].y) / 2 : row++ * ROW;
    kids.forEach((k) => links.push([item, k]));
    out.push(item);
    return item;
  };
  walk(G.root, 0);
  return { out, links, height: row * ROW };
}
const radius = (size) => Math.max(4, Math.min(13, 4 + 9 * Math.sqrt(size / G.total)));

function drawGraph() {
  if (!G.root) return;
  const { out, links, height } = layout();
  const g = $("#graphG"), svg = $("#graph");
  if (!G.fitted && svg.clientHeight) {
    const width = Math.max(...out.map((o) => o.x)) + 200;
    const availH = svg.clientHeight - 110, availW = svg.clientWidth - 60;
    G.k = Math.max(0.35, Math.min(1, availH / Math.max(height, 1), availW / width));
    G.tx = 30;
    G.ty = 50 + Math.max(0, (availH - height * G.k) / 2) + (ROW / 2) * G.k;
    G.fitted = true;
  }
  const ln = links.map(([a, b]) => {
    const mx = (a.x + b.x) / 2;
    return `<path class="link" d="M${a.x},${a.y}C${mx},${a.y} ${mx},${b.y} ${b.x},${b.y}"/>`;
  }).join("");
  const nd = out.map((o, i) => {
    const r = radius(o.d.size);
    const mark = !o.pseudo && o.d.has_children && !o.n.expanded ? `<text class="plus" y="3.5">+</text>` : "";
    return `<g class="node${o.pseudo ? " pseudo" : ""}${G.sel === o.d.path && o.d.path !== null ? " sel" : ""}" data-i="${i}" transform="translate(${o.x},${o.y})"
      ${o.pseudo ? "" : 'tabindex="0" role="button"'} aria-label="${esc(o.d.name)}, ${fmtSize(o.d.size)}">
      <circle r="${r}" fill="var(--c-${o.d.cat || "autres"})" ${o.pseudo ? 'opacity=".45"' : ""}/>${r >= 7 ? mark : ""}
      <text x="${r + 6}" y="-1">${esc(o.d.name.length > 30 ? o.d.name.slice(0, 29) + "…" : o.d.name)}</text>
      <text class="sz" x="${r + 6}" y="12">${fmtSize(o.d.size)}</text></g>`;
  }).join("");
  g.innerHTML = ln + nd;
  g.setAttribute("transform", `translate(${G.tx},${G.ty}) scale(${G.k})`);
  $$(".node:not(.pseudo)", g).forEach((el) => {
    const o = out[+el.dataset.i];
    const act = async () => {
      if (G.moved) return;
      G.sel = o.d.path;
      if (o.d.path !== "") {
        try {
          const n = await loadNode(o.d.path);
          n.expanded = !n.expanded;
          renderSide(n.data);
        } catch (e) { toast("Ce dossier n'existe plus : relance l'analyse."); }
      }
      drawGraph();
    };
    el.onclick = act;
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); act(); } };
  });
}
function renderSide(d) {
  const cats = Object.keys(d.cats || {}).length ? `${catBar(d.cats, d.size)}<div class="legend">${legend(d.cats)}</div>` : "";
  const subs = (d.children || []).slice(0, 8).map((c) => `<li><span>${esc(c.name)}</span><span class="num muted">${fmtSize(c.size)}</span></li>`).join("");
  const files = (d.top_files || []).map((f) => `<li><span data-tip="${esc(f.name)}">${esc(f.name)}</span><span class="num muted">${fmtSize(f.size)}</span></li>`).join("");
  $("#graphSide").innerHTML = `<h3>${esc(d.name)}</h3><div class="path">${esc(shortPath(d.path))}</div>
    ${d.protected ? '<p class="badge warn" style="margin-bottom:10px;white-space:normal">Données d\'une application : Cloud Cleaner n\'y touche pas.</p>' : ""}
    <div class="kv"><span>Taille</span><span class="num">${fmtSize(d.size)}</span><span>Fichiers</span><span class="num">${fmtNum(d.files)}</span>
    <span>Dernière modification</span><span>${fmtDate(d.newest) || "—"}</span><span>Part du total</span><span class="num">${(d.size / G.total * 100).toFixed(1).replace(".", ",")} %</span></div>
    ${cats}${subs ? `<h4>Plus gros sous-dossiers</h4><ul>${subs}</ul>` : ""}${files ? `<h4>Plus gros fichiers ici</h4><ul>${files}</ul>` : ""}
    <button class="btn" style="margin-top:14px" id="sideReveal">Afficher dans le Finder</button>`;
  $("#sideReveal").onclick = () => reveal(d.path);
}
(function panZoom() {
  const svg = $("#graph");
  let start = null;
  const apply = () => $("#graphG").setAttribute("transform", `translate(${G.tx},${G.ty}) scale(${G.k})`);
  svg.addEventListener("pointerdown", (e) => { start = { x: e.clientX, y: e.clientY, tx: G.tx, ty: G.ty }; G.moved = false; });
  window.addEventListener("pointermove", (e) => {
    if (!start) return;
    const dx = e.clientX - start.x, dy = e.clientY - start.y;
    if (Math.abs(dx) + Math.abs(dy) > 4) { G.moved = true; svg.classList.add("drag"); }
    if (G.moved) { G.tx = start.tx + dx; G.ty = start.ty + dy; apply(); }
  });
  window.addEventListener("pointerup", () => { start = null; svg.classList.remove("drag"); setTimeout(() => (G.moved = false), 0); });
  svg.addEventListener("wheel", (e) => {
    e.preventDefault();
    const rect = svg.getBoundingClientRect();
    const px = e.clientX - rect.left, py = e.clientY - rect.top;
    const k2 = Math.max(0.25, Math.min(3, G.k * (e.deltaY < 0 ? 1.12 : 1 / 1.12)));
    G.tx = px - (px - G.tx) * (k2 / G.k); G.ty = py - (py - G.ty) * (k2 / G.k); G.k = k2;
    apply();
  }, { passive: false });
  $("#graphReset").onclick = () => { G.fitted = false; drawGraph(); };
})();

// ---------- orchestration ----------
function showTab(t) {
  S.tab = t;
  $$(".tabs button").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === t));
  $$(".tab").forEach((s) => (s.hidden = s.id !== "tab-" + t));
  if (t === "graph") drawGraph();
  scrollTo(0, 0);
}
$$(".tabs button").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));

function renderMaj() {
  const m = S.state?.maj || {};
  $("#version").textContent = m.version && m.version !== "dev" ? `· version ${m.version}` : "";
  const b = $("#majBanner");
  b.hidden = m.state !== "prete";
  if (!b.hidden) {
    b.textContent = `Nouvelle version ${m.nouvelle} prête : elle s'installera au prochain lancement de Cloud Cleaner.` +
      (m.notes ? ` Nouveautés : ${m.notes}` : "");
  }
}
// La vérification des mises à jour se fait en arrière-plan : on regarde de temps en temps.
setInterval(async () => {
  if (polling) return;
  try { S.state = await api("/api/state"); renderMaj(); } catch (e) { /* hors ligne */ }
}, 20000);

function renderProgress() {
  renderMaj();
  const p = S.state.progress, box = $("#progress");
  const jobRunning = renderJob();
  const busy = scanBusy();
  box.hidden = !busy && p.state !== "error";
  const sb = $("#scanBtn");
  sb.disabled = busy || jobRunning;
  sb.textContent = S.state.summary ? "Relancer l'analyse" : "Analyser mes clouds";
  if (p.state === "scanning") $("#progressText").textContent = `Je regarde tes dossiers… ${fmtNum(p.files)} fichiers, ${fmtSize(p.bytes)}`;
  else if (p.state === "analyzing") $("#progressText").textContent = p.phase === "doublons" ? `Je compare les fichiers pour trouver les doublons… ${fmtNum(p.done)} / ${fmtNum(p.total)}` : "Je prépare les propositions…";
  else if (p.state === "error") $("#progressText").textContent = "L'analyse a échoué : " + p.error;
  $$("[data-act], #cleanBtn, #scanBtn2").forEach((b) => { if (busy || jobRunning) b.disabled = true; });
  return busy || jobRunning;
}

async function refresh() {
  S.state = await api("/api/state");
  S.catOrder = S.state.cat_order;
  const busy = renderProgress();
  [S.recos, S.journal] = await Promise.all([api("/api/recos"), api("/api/journal")]);
  initSel();
  const nJ = S.journal.filter((o) => o.status === "done" && o.count).length;
  $("#journalCount").hidden = !nJ; $("#journalCount").textContent = nJ;
  renderHome(); renderRecos(); renderJournal();
  if (busy) poll(); else await initGraph();
}
let polling = false;
function poll() {
  if (polling) return;
  polling = true;
  const tick = async () => {
    try { S.state = await api("/api/state"); } catch (e) { polling = false; return toast(e.message); }
    if (renderProgress()) return setTimeout(tick, 600);
    polling = false;
    await refresh();
  };
  tick();
}
async function startScan() {
  try { await api("/api/scan", {}); } catch (e) { toast(e.message); return; }
  poll();
}
$("#scanBtn").onclick = startScan;
refresh().catch((e) => toast(e.message));
