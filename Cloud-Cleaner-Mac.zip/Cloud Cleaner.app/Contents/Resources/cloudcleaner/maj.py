"""Mises à jour automatiques signées (même principe que Sillon).

- À chaque lancement, l'app lit `version.json` sur GitHub Pages (dépôt public CLOUD-CLEANER).
- Un paquet n'est accepté que s'il est signé par la clé privée de l'auteur (Ed25519) et que son
  empreinte SHA-256 correspond. Sinon il est ignoré.
- Le paquet vérifié est rangé dans ~/Library/Application Support/CloudCleaner/code et appliqué
  au lancement SUIVANT par le lanceur de l'app. Une version qui ne démarre pas est abandonnée
  et l'app repart sur la précédente.
Rien n'est jamais exécuté depuis Internet avant vérification.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import shutil
import tempfile
import threading
import urllib.request
import zipfile

from . import ed25519

BASE_URL = os.environ.get("CC_MAJ_URL") or "https://arthurreeb2-tech.github.io/CLOUD-CLEANER/"
# Clé publique Ed25519 (32 octets, base64). La clé privée ne quitte jamais le Mac de l'auteur.
CLE_PUBLIQUE = "Gw1wCUdi0EnWM5xhcl57py+S1PLaBlIvtiXKhCOvdVM="

CODE_DIR = os.environ.get("CC_SUP") or os.path.join(
    os.path.expanduser("~"), "Library", "Application Support", "CloudCleaner", "code")


def version_actuelle() -> str:
    try:
        with open(os.path.join(os.path.dirname(__file__), "VERSION"), encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return "dev"


def signature_valide(version: str, sha256: str, signature_b64: str, cle_b64: str = CLE_PUBLIQUE) -> bool:
    try:
        cle = base64.b64decode(cle_b64)
        sig = base64.b64decode(signature_b64)
    except (ValueError, TypeError):
        return False
    return ed25519.verify(cle, f"{version}|{sha256}".encode(), sig)


class Majeur:
    """Vérifie, télécharge et prépare une mise à jour en tâche de fond."""

    def __init__(self, base_url: str = BASE_URL, cle: str = CLE_PUBLIQUE, code_dir: str = CODE_DIR,
                 courante: str | None = None):
        self.base_url = base_url.rstrip("/") + "/"
        self.cle = cle
        self.code_dir = code_dir
        self.courante = courante or version_actuelle()
        self.etat: dict = {"version": self.courante, "state": "idle"}

    def _get(self, url: str, timeout: float = 10) -> bytes:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
        with opener.open(req, timeout=timeout) as r:
            return r.read()

    def _mauvaises(self) -> set:
        try:
            with open(os.path.join(self.code_dir, "mauvaises"), encoding="utf-8") as fh:
                return {line.strip() for line in fh if line.strip()}
        except OSError:
            return set()

    def demarrer(self) -> None:
        if self.courante == "dev":
            self.etat = {"version": "dev", "state": "dev"}
            return
        threading.Thread(target=self.verifier, daemon=True).start()

    def verifier(self) -> dict:
        try:
            self.etat = {"version": self.courante, "state": "checking"}
            info = json.loads(self._get(self.base_url + "version.json", timeout=8))
            v, sha, sig = str(info["version"]), str(info["sha256"]), str(info["signature"])
            fichier = os.path.basename(str(info["fichier"]))
            if not signature_valide(v, sha, sig, self.cle):
                self.etat = {"version": self.courante, "state": "refusee",
                             "detail": "signature invalide : mise à jour ignorée"}
                return self.etat
            if v <= self.courante or v in self._mauvaises():
                self.etat = {"version": self.courante, "state": "a_jour", "derniere": v}
                return self.etat
            dest = os.path.join(self.code_dir, "versions", v)
            if not os.path.isfile(os.path.join(dest, "cloudcleaner", "__main__.py")):
                data = self._get(self.base_url + "maj/" + fichier, timeout=60)
                if hashlib.sha256(data).hexdigest() != sha:
                    self.etat = {"version": self.courante, "state": "refusee",
                                 "detail": "paquet modifié en route : mise à jour ignorée"}
                    return self.etat
                self._installer(data, v, dest)
            with open(os.path.join(self.code_dir, "prochaine.tmp"), "w", encoding="utf-8") as fh:
                fh.write(v)
            os.replace(os.path.join(self.code_dir, "prochaine.tmp"),
                       os.path.join(self.code_dir, "prochaine"))
            self.etat = {"version": self.courante, "state": "prete", "nouvelle": v,
                         "notes": str(info.get("notes", ""))}
        except Exception as exc:  # noqa: BLE001 — hors ligne, page absente… : on réessaiera
            self.etat = {"version": self.courante, "state": "hors_ligne", "detail": str(exc)[:120]}
        return self.etat

    def _installer(self, data: bytes, v: str, dest: str) -> None:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = tempfile.mkdtemp(prefix=f".{v}-", dir=os.path.dirname(dest))
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for name in z.namelist():  # aucun chemin qui sorte du dossier
                    if name.startswith("/") or ".." in name.split("/"):
                        raise ValueError("paquet invalide")
                z.extractall(tmp)
            with open(os.path.join(tmp, "cloudcleaner", "VERSION"), encoding="utf-8") as fh:
                if fh.read().strip() != v:
                    raise ValueError("version du paquet incohérente")
            if not os.path.isfile(os.path.join(tmp, "cloudcleaner", "__main__.py")):
                raise ValueError("paquet incomplet")
            if os.path.exists(dest):
                shutil.rmtree(dest)
            os.replace(tmp, dest)
        finally:
            if os.path.exists(tmp):
                shutil.rmtree(tmp, ignore_errors=True)
        # Ménage : on garde les 3 versions les plus récentes.
        vdir = os.path.dirname(dest)
        for old in sorted(n for n in os.listdir(vdir) if not n.startswith("."))[:-3]:
            shutil.rmtree(os.path.join(vdir, old), ignore_errors=True)
