"""Actions sur les fichiers : mise à la corbeille Cloud Cleaner (quarantaine), déplacement
sur ce Mac (archivage), rangement, remise en place et suppression définitive.

Journal : un fichier par opération (`journal/<id>.jsonl`), en ajout seul.
- L'intention est écrite AVANT chaque déplacement, la confirmation APRÈS : une coupure
  (app fermée, Mac éteint) ne fait jamais perdre la trace d'un fichier déplacé.
- Chaque opération a son propre fichier : deux actions ne peuvent pas s'écraser.
- Une ligne illisible (fin de fichier tronquée) est ignorée sans toucher au reste.
Rien n'est supprimé sans la suppression définitive explicite d'une quarantaine.
"""
from __future__ import annotations

import errno
import json
import os
import shutil
import subprocess
import threading
import time
import uuid

from .scanner import Source


class ActionError(Exception):
    pass


class PartialMove(Exception):
    """La copie est complète à destination, mais la source n'a pas pu être entièrement retirée."""


SF_DATALESS = 0x40000000
ONEDRIVE_SYSTEM_DIRS = {"desktop", "bureau", "documents", "pictures", "images"}
GDRIVE_MY_DRIVE = {"My Drive", "Mon Drive", "Mi unidad", "Meine Ablage", "Il mio Drive"}
# Dossiers système synchronisés par iCloud (« Bureau et Documents ») : jamais déplacés en bloc.
ICLOUD_SYSTEM_DIRS = {"Desktop", "Documents"}


def _is_dataless(path: str) -> bool:
    try:
        return bool(getattr(os.lstat(path), "st_flags", 0) & SF_DATALESS)
    except OSError:
        return False


def _is_icloud_stub(name: str) -> bool:
    return name.startswith(".") and name.endswith(".icloud")


# Documents Google natifs : sur le Mac, ce ne sont que des raccourcis vers le document en
# ligne. Les sortir de Google Drive enverrait le vrai document à la corbeille Google.
GOOGLE_NATIVE_EXTS = {".gdoc", ".gsheet", ".gslides", ".gdraw", ".gform", ".gmap", ".gsite",
                      ".gjam", ".gtable", ".gscript", ".glink", ".gnote", ".gvid"}


def is_google_native(name: str) -> bool:
    return os.path.splitext(name)[1].lower() in GOOGLE_NATIVE_EXTS


def check_movable(path: str) -> None:
    """Refuse tout élément qui est (ou contient) un document Google natif."""
    if is_google_native(os.path.basename(path)):
        raise ActionError("document Google (Docs, Sheets…) : il ne vit qu'en ligne, Cloud Cleaner n'y touche pas")
    if os.path.isdir(path) and not os.path.islink(path):
        for _root, _dirs, names in os.walk(path):
            if any(is_google_native(n) for n in names):
                raise ActionError("contient des documents Google (Docs, Sheets…) : Cloud Cleaner n'y touche pas")


def materialize(path: str) -> None:
    """Télécharge sur ce Mac tout fichier resté dans le cloud, AVANT de le déplacer.
    Lire un fichier « en ligne seulement » oblige macOS à le rapatrier ; on vérifie ensuite.
    Si un fichier ne descend pas, on refuse le déplacement (rien n'est touché)."""
    targets = []
    if os.path.isdir(path) and not os.path.islink(path):
        for root, _dirs, names in os.walk(path):
            for n in names:
                p = os.path.join(root, n)
                if _is_icloud_stub(n):
                    raise ActionError("contient des fichiers iCloud pas encore téléchargés")
                if _is_dataless(p):
                    targets.append(p)
    elif _is_dataless(path):
        targets.append(path)
    for p in targets:
        with open(p, "rb") as fh:
            while fh.read(4 * 1024 * 1024):
                pass
        if _is_dataless(p):
            raise ActionError("le fichier n'a pas pu être téléchargé depuis le cloud")


DITTO = "/usr/bin/ditto"


def _copy_all(src: str, dst: str) -> None:
    """Copie complète. Sur Mac, `ditto` garde tout (étiquettes Finder, attributs étendus,
    autorisations, dates) ; Python seul les perdrait."""
    if os.path.exists(DITTO):
        res = subprocess.run([DITTO, src, dst], capture_output=True, text=True)
        if res.returncode != 0:
            raise OSError(res.returncode, res.stderr.strip() or "copie impossible")
    elif os.path.isdir(src) and not os.path.islink(src):
        shutil.copytree(src, dst, symlinks=True)
    else:
        shutil.copy2(src, dst, follow_symlinks=False)


def move(src: str, dst: str) -> None:
    """Déplacement sûr. Même disque : renommage. Autre disque : copie complète, puis retrait
    de la source ; une copie ratée est effacée (la source reste intacte)."""
    try:
        os.rename(src, dst)
        return
    except OSError as exc:
        if exc.errno != errno.EXDEV:
            raise
    try:
        _copy_all(src, dst)
    except BaseException:
        if os.path.isdir(dst) and not os.path.islink(dst):
            shutil.rmtree(dst, ignore_errors=True)
        elif os.path.lexists(dst):
            os.remove(dst)
        raise
    try:
        if os.path.isdir(src) and not os.path.islink(src):
            shutil.rmtree(src)
        else:
            os.remove(src)
    except OSError as exc:
        # Le cloud refuse de retirer l'original : on remet ce qui a déjà été retiré puis on
        # efface la copie. Résultat : l'élément reste entier à sa place, rien n'est déplacé.
        try:
            _merge_into(dst, src)
            _remove(dst)
        except Exception:  # noqa: BLE001 — retour impossible : la copie complète est gardée
            raise PartialMove(f"copié, mais l'original n'a pas pu être entièrement retiré ({exc})")
        raise ActionError(f"le cloud a refusé de retirer l'original ({exc}) : laissé en place")


def _remove(path: str) -> None:
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    elif os.path.lexists(path):
        os.remove(path)


def _merge_into(src: str, dst: str) -> None:
    """Complète dst avec ce qui n'y est plus, depuis src. N'écrase JAMAIS un élément présent
    dans dst (une copie interrompue peut contenir des fichiers tronqués)."""
    if not os.path.lexists(dst):
        _copy_all(src, dst)
        return
    if not (os.path.isdir(src) and not os.path.islink(src)):
        return  # fichier : l'original est là, on le garde tel quel
    for root, dirs, names in os.walk(src):
        rel = os.path.relpath(root, src)
        target_root = dst if rel == "." else os.path.join(dst, rel)
        for d in list(dirs):
            t = os.path.join(target_root, d)
            if not os.path.lexists(t):
                _copy_all(os.path.join(root, d), t)
                dirs.remove(d)  # copié en entier, inutile d'y descendre
        for n in names:
            t = os.path.join(target_root, n)
            if not os.path.lexists(t):
                _copy_all(os.path.join(root, n), t)


class Workspace:
    def __init__(self, data_dir: str, archive_dir: str, sources: list[Source]):
        self.data_dir = data_dir
        self.archive_dir = archive_dir
        self.quarantine_dir = os.path.join(data_dir, "Quarantaine")
        self.journal_dir = os.path.join(data_dir, "journal")
        self.sources = [s for s in sources if s.present]
        self.lock = threading.RLock()
        self.guard = None  # vérification « inchangé depuis l'analyse », fournie par le serveur
        os.makedirs(self.quarantine_dir, exist_ok=True)
        os.makedirs(self.journal_dir, exist_ok=True)
        self._migrate_legacy()

    # ---------- journal ----------
    def _op_path(self, op_id: str) -> str:
        if not op_id or "/" in op_id or op_id.startswith("."):
            raise ActionError("Opération inconnue.")
        return os.path.join(self.journal_dir, op_id + ".jsonl")

    def _append(self, op_id: str, *records: dict) -> None:
        path = self._op_path(op_id)
        with self.lock:
            # Dernière ligne coupée par une coupure : on repart sur une ligne neuve pour ne
            # pas coller (et perdre) l'enregistrement suivant.
            try:
                with open(path, "rb") as fh:
                    fh.seek(-1, os.SEEK_END)
                    if fh.read(1) != b"\n":
                        records = ({"_": "reprise"},) + tuple(records)
                        with open(path, "a", encoding="utf-8") as fa:
                            fa.write("\n")
            except OSError:
                pass  # fichier neuf ou vide
        with self.lock, open(path, "a", encoding="utf-8") as fh:
            for rec in records:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            os.fsync(fh.fileno())

    def _new_op(self, kind: str) -> str:
        op_id = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        self._append(op_id, {"op": op_id, "type": kind, "date": time.time()})
        return op_id

    def load_op(self, op_id: str) -> dict | None:
        try:
            with open(self._op_path(op_id), encoding="utf-8") as fh:
                lines = fh.readlines()
        except OSError:
            return None
        op: dict | None = None
        intents: dict[int, dict] = {}
        state: dict[int, str] = {}   # moved | failed | restored | purged
        errors: list[dict] = []
        partial: set[int] = set()    # copie complète, mais des restes dans le cloud
        for line in lines:
            try:
                rec = json.loads(line)
            except ValueError:
                continue  # ligne tronquée par une coupure : ignorée
            if "op" in rec:
                op = {"id": rec["op"], "type": rec["type"], "date": rec["date"],
                      "status": "done", "cancelled": False}
            elif "m" in rec:
                intents[rec["i"]] = {"src": rec["m"][0], "dst": rec["m"][1], "size": rec["m"][2]}
            elif "ok" in rec:
                state[rec["ok"]] = "moved"
                if rec.get("partial"):
                    partial.add(rec["ok"])
                if rec.get("warn"):
                    errors.append({"path": intents.get(rec["ok"], {}).get("src", ""),
                                   "error": rec["warn"]})
            elif "fail" in rec:
                state[rec["fail"]] = "failed"
                errors.append({"path": intents.get(rec["fail"], {}).get("src", ""),
                               "error": rec.get("error", "")})
            elif "restored" in rec:
                state[rec["restored"]] = "restored"
            elif "purged" in rec:
                state[rec["purged"]] = "purged"
            elif "status" in rec and op:
                op["status"] = rec["status"]
            elif "cancelled" in rec and op:
                op["cancelled"] = True
        if op is None:
            return None
        items, recovered = [], 0
        for i, it in sorted(intents.items()):
            st = state.get(i)
            if st is None:  # coupure pendant le déplacement : on regarde le disque
                if os.path.lexists(it["dst"]):
                    st = "moved"
                    recovered += 1
                    # Original encore présent : copie peut-être incomplète ou original à
                    # moitié retiré. Copie de sécurité : jamais effacée, remise par fusion.
                    if os.path.lexists(it["src"]):
                        partial.add(i)
                else:
                    continue
            if st == "moved":
                # Remise en place interrompue juste avant d'être notée : l'élément est revenu.
                if not os.path.lexists(it["dst"]) and os.path.lexists(it["src"]):
                    state[i] = "restored"
                    continue
                items.append({**it, "i": i, "partial": i in partial})
        op.update(items=items, errors=errors, size=sum(i["size"] for i in items),
                  count=len(items), recovered=recovered)
        if op["status"] == "done" and not items and any(
                s in ("restored", "purged") for s in state.values()):
            op["status"] = "purged" if "purged" in state.values() else "restored"
        return op

    def journal(self) -> list[dict]:
        ops = []
        for name in sorted(os.listdir(self.journal_dir)):
            if name.endswith(".jsonl"):
                op = self.load_op(name[:-6])
                if op:
                    ops.append(op)
        ops.sort(key=lambda o: o["date"])
        return ops

    def _migrate_legacy(self) -> None:
        """Reprend l'ancien journal.json (versions précédentes) au nouveau format."""
        legacy = os.path.join(self.data_dir, "journal.json")
        if not os.path.exists(legacy):
            return
        try:
            with open(legacy, encoding="utf-8") as fh:
                old = json.load(fh)
        except (OSError, ValueError):
            return  # illisible : laissé en place, jamais écrasé
        for o in old:
            if os.path.exists(self._op_path(o["id"])):
                continue
            recs = [{"op": o["id"], "type": o["type"], "date": o["date"]}]
            for i, it in enumerate(o.get("items", [])):
                recs += [{"i": i, "m": [it["src"], it["dst"], it["size"]]}, {"ok": i}]
            if o.get("status") in ("restored", "purged"):
                recs.append({"status": o["status"]})
            self._append(o["id"], *recs)
        os.replace(legacy, legacy + ".migre")

    # ---------- validation ----------
    def locate(self, path: str) -> tuple[Source, str]:
        """Vérifie qu'un chemin est modifiable ; renvoie sa source et son chemin relatif."""
        if not isinstance(path, str) or not os.path.isabs(path) or os.path.normpath(path) != path:
            raise ActionError(f"Chemin invalide : {path}")
        for s in self.sources:
            base = s.root
            if s.id == "icloud":  # seules les données de iCloud Drive sont modifiables
                base = os.path.join(s.root, "com~apple~CloudDocs")
            if not path.startswith(base.rstrip("/") + "/"):
                continue
            rel = os.path.relpath(path, base)
            # Google Drive : seul le contenu de « Mon Drive » est modifiable. « Mon Drive »
            # lui-même, les Drives partagés (communs à d'autres personnes) et « Autres
            # ordinateurs » ne le sont jamais.
            if s.id.startswith("gdrive") and ("/" not in rel or
                                              rel.split("/")[0] not in GDRIVE_MY_DRIVE):
                raise ActionError(f"Seul le contenu de « Mon Drive » est modifiable : {path}")
            if is_google_native(os.path.basename(path)):
                raise ActionError(f"Document Google natif, jamais déplacé : {path}")
            if s.id == "icloud" and rel.lower() in {d.lower() for d in ICLOUD_SYSTEM_DIRS}:
                raise ActionError(f"Dossier Bureau ou Documents d'iCloud non modifiable : {path}")
            # OneDrive : dossiers sauvegardés automatiquement (Bureau, Documents, Images).
            if s.id.startswith("onedrive") and rel.lower() in ONEDRIVE_SYSTEM_DIRS:
                raise ActionError(f"Dossier sauvegardé par OneDrive non modifiable : {path}")
            if _is_icloud_stub(os.path.basename(path)):
                raise ActionError(f"Fichier iCloud pas encore téléchargé : {path}")
            # Aucun lien symbolique dans le chemin : il pourrait mener hors du cloud.
            real_base = os.path.realpath(base)
            if os.path.relpath(os.path.realpath(path), real_base) != rel:
                raise ActionError(f"Chemin passant par un lien symbolique, refusé : {path}")
            return s, rel
        raise ActionError(f"Chemin hors des dossiers cloud modifiables : {path}")

    @staticmethod
    def _free_name(dst: str, taken: set) -> str:
        stem, ext = os.path.splitext(dst)
        cand, n = dst, 2
        while os.path.lexists(cand) or cand in taken:
            cand = f"{stem} ({n}){ext}"
            n += 1
        taken.add(cand)
        return cand

    @staticmethod
    def _size(path: str) -> int:
        if os.path.isdir(path) and not os.path.islink(path):
            total = 0
            for root, _dirs, names in os.walk(path):
                for n in names:
                    try:
                        total += os.lstat(os.path.join(root, n)).st_size
                    except OSError:
                        pass
            return total
        return os.lstat(path).st_size

    # ---------- déplacements ----------
    def _run(self, kind: str, pairs: list[tuple[str, str]],
             progress: dict | None = None, cancel=None) -> dict:
        progress = progress if progress is not None else {}
        progress.update(total=len(pairs), done=0, bytes=0, current="", failed=0)
        op_id = self._new_op(kind)
        taken: set = set()
        for i, (src, dst) in enumerate(pairs):
            if cancel is not None and cancel.is_set():
                self._append(op_id, {"cancelled": True})
                break
            progress["current"] = src
            try:
                if not os.path.lexists(src):
                    raise ActionError("introuvable (déjà déplacé ?)")
                if os.path.islink(src):
                    raise ActionError("lien symbolique ignoré")
                check_movable(src)
                if self.guard is not None:  # rien n'a changé depuis l'analyse ?
                    self.guard(src)
                if kind != "organize":  # rangement = même cloud : pas besoin de télécharger
                    materialize(src)
                size = self._size(src)
                dst = self._free_name(dst, taken)
                self._append(op_id, {"i": i, "m": [src, dst, size]})  # intention d'abord
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                try:
                    move(src, dst)
                    self._append(op_id, {"ok": i})
                except PartialMove as exc:  # copie complète gardée et journalisée
                    self._append(op_id, {"ok": i, "partial": True,
                                         "warn": f"{exc} : copie de sécurité gardée, jamais "
                                                 "effacée par « Vider la corbeille »"})
                    progress["failed"] += 1
                progress["bytes"] += size
            except Exception as exc:  # noqa: BLE001 — une erreur sur un élément ne bloque pas le lot
                self._append(op_id, {"fail": i, "error": str(exc)})
                progress["failed"] += 1
            progress["done"] += 1
        op = self.load_op(op_id) or {"id": op_id, "items": [], "errors": [], "size": 0}
        if not op["items"] and not op["errors"]:
            os.remove(self._op_path(op_id))  # opération vide : rien à garder
        return op

    @staticmethod
    def _dedupe(paths: list[str]) -> list[str]:
        """Retire les chemins déjà couverts par un dossier parent sélectionné."""
        chosen = set(paths)
        out = []
        for p in sorted(chosen):
            parts = p.split("/")
            if not any("/".join(parts[:k]) in chosen for k in range(2, len(parts))):
                out.append(p)
        return out

    def quarantine(self, paths: list[str], progress=None, cancel=None) -> dict:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        pairs = []
        for p in self._dedupe(paths):
            s, rel = self.locate(p)
            pairs.append((p, os.path.join(self.quarantine_dir, stamp, s.label, rel)))
        return self._run("quarantine", pairs, progress, cancel)

    def archive(self, paths: list[str], progress=None, cancel=None) -> dict:
        pairs = []
        for p in self._dedupe(paths):
            s, rel = self.locate(p)
            pairs.append((p, os.path.join(self.archive_dir, s.label, rel)))
        return self._run("archive", pairs, progress, cancel)

    def organize(self, moves: list[dict], progress=None, cancel=None) -> dict:
        pairs = []
        for m in moves:
            s1, _ = self.locate(m["path"])
            s2, _ = self.locate(m["dest"])
            if s1.id != s2.id:
                raise ActionError("Le rangement doit rester dans le même cloud.")
            pairs.append((m["path"], m["dest"]))
        return self._run("organize", pairs, progress, cancel)

    # ---------- remise en place / suppression définitive ----------
    def restore(self, op_id: str, progress=None, cancel=None) -> dict:
        op = self.load_op(op_id)
        if not op or op["status"] != "done" or not op["items"]:
            raise ActionError("Opération introuvable ou déjà traitée.")
        progress = progress if progress is not None else {}
        progress.update(total=len(op["items"]), done=0, bytes=0, current="", failed=0)
        restored, errors = [], []
        for it in reversed(op["items"]):
            if cancel is not None and cancel.is_set():
                break
            progress["current"] = it["src"]
            try:
                # Le cloud d'origine doit être là (app ouverte et connectée) : sinon on
                # recréerait un faux dossier local qui ne se synchronise pas.
                try:
                    s, _rel = self.locate(it["src"])
                except ActionError:
                    raise ActionError("le cloud d'origine n'est pas disponible : ouvre son app, "
                                      "vérifie qu'elle est connectée, puis réessaie")
                if not os.path.isdir(s.root):
                    raise ActionError(f"{s.label} n'est pas disponible sur ce Mac pour l'instant")
                if not os.path.lexists(it["dst"]):
                    raise ActionError("introuvable dans la corbeille ou les archives")
                if it.get("partial") and os.path.lexists(it["src"]):
                    # Restes de l'original encore dans le cloud : on complète avec la copie.
                    _merge_into(it["dst"], it["src"])
                    _remove(it["dst"])
                else:
                    if os.path.lexists(it["src"]):
                        raise ActionError("un élément existe déjà à l'emplacement d'origine (si "
                                          "une opération plus récente concerne le même dossier, "
                                          "remets-la d'abord en place)")
                    os.makedirs(os.path.dirname(it["src"]), exist_ok=True)
                    try:
                        move(it["dst"], it["src"])
                    except PartialMove as exc:  # remis en place ; une copie reste en plus
                        errors.append({"path": it["src"], "error": str(exc)})
                self._append(op_id, {"restored": it["i"]})
                restored.append(it["src"])
                progress["bytes"] += it["size"]
            except Exception as exc:  # noqa: BLE001 — une erreur sur un élément ne bloque pas le lot
                errors.append({"path": it["src"], "error": str(exc)})
                progress["failed"] += 1
            progress["done"] += 1
        return {"restored": restored, "errors": errors, "op": self.load_op(op_id)}

    def purge(self, op_id: str, progress=None, cancel=None) -> dict:
        """Suppression définitive du contenu d'une quarantaine."""
        op = self.load_op(op_id)
        if not op or op["status"] != "done" or op["type"] != "quarantine":
            raise ActionError("Seule une mise à la corbeille en cours peut être supprimée.")
        progress = progress if progress is not None else {}
        progress.update(total=len(op["items"]), done=0, bytes=0, current="", failed=0)
        freed, errors = 0, []
        qroot = self.quarantine_dir.rstrip("/") + "/"
        for it in op["items"]:
            dst = it["dst"]
            progress["current"] = it["src"]
            if it.get("partial"):  # seule copie complète : jamais effacée automatiquement
                errors.append({"path": it["src"], "error": "copie de sécurité gardée (l'original "
                               "n'a pas pu être retiré du cloud) : utilise « Tout remettre »"})
                progress["failed"] += 1
                progress["done"] += 1
                continue
            # Garde-fou : ne supprime que dans la quarantaine, sans lien symbolique.
            if not dst.startswith(qroot) or os.path.normpath(dst) != dst or \
                    os.path.realpath(dst) != os.path.join(os.path.realpath(self.quarantine_dir),
                                                          os.path.relpath(dst, self.quarantine_dir)):
                errors.append({"path": dst, "error": "hors de la corbeille Cloud Cleaner"})
                progress["failed"] += 1
                progress["done"] += 1
                continue
            try:
                if os.path.isdir(dst) and not os.path.islink(dst):
                    shutil.rmtree(dst)
                elif os.path.lexists(dst):
                    os.remove(dst)
                self._append(op_id, {"purged": it["i"]})
                freed += it["size"]
                progress["bytes"] += it["size"]
                d = os.path.dirname(dst)  # retire les dossiers devenus vides
                while d.startswith(qroot):
                    try:
                        os.rmdir(d)
                    except OSError:
                        break
                    d = os.path.dirname(d)
            except OSError as exc:
                errors.append({"path": dst, "error": str(exc)})
                progress["failed"] += 1
            progress["done"] += 1
        return {"freed": freed, "errors": errors, "op": self.load_op(op_id)}
